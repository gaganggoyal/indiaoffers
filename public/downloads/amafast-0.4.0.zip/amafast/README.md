# AmaFast

AmaFast is an unpacked Chrome extension for your own Amazon.in account. You click Amazon's **Buy Now**. The extension then:

1. Keeps the delivery address and delivery speed Amazon already selected.
2. Chooses **Internet Banking** / **Net Banking** and a bank (the first one listed, or a bank you named).
3. Submits that Amazon step.
4. Does **not** sign in on the bank page.
5. Opens **Your Orders**, where Amazon lets you revise a failed or unfinished payment and pay with UPI, a card, or another method you choose.

Amazon does not ship the order until that later payment succeeds. If the order stays on “awaiting confirmation from your bank”, refresh Your Orders and use **Change payment method** when it appears, or cancel the order there.

AmaFast is not affiliated with Amazon.

## Install

1. Open `chrome://extensions`.
2. Turn on **Developer mode**.
3. Click **Load unpacked** and choose this folder (`amafast`).
4. Pin AmaFast if you want the popup handy.
5. On Amazon.in, set the site language to **English** if a step is missed. Hindi labels for Buy Now, Net Banking, and a few checkout buttons are also recognised.

Use a saved Amazon address and stay signed in. The extension does not type your Amazon or bank password.

## Use

On a product page, leave the **AmaFast** card **On** and click **Buy Now**. A status line shows each step. **Stop** cancels the rest of the automation. **Off** makes Buy Now behave normally.

**Test mode** (popup or settings) selects Internet Banking and a bank, then stops before the order is placed.

If the place-order click does not register, AmaFast retries it once, then stops and says so rather than reporting an order that was never created. Clicking **Buy Now** again while an order is already in flight does not start a second run.

Leave **Preferred bank** blank to take the first real bank in Amazon's list. A name such as `SBI` or `HDFC` is used when that bank is on the list.

## Deals from IndiaOffers.in

The popup lists loot deals from [IndiaOffers.in](https://indiaoffers.in), refreshed
every 20 minutes. Opening one goes through the site's own `/go/` redirect, which
attaches the affiliate tag and forwards you to the store — so the referral is
earned by the deal listing you clicked, the way any deals site works. We may earn
a commission on those, at no extra cost to you.

On a product page you reached yourself, AmaFast shows the price and best bank
offer it has on record for that ASIN, matched locally against the downloaded
list. That line is information only: it does not redirect you, does not gate
checkout, and **never adds or changes an affiliate tag on a link you are already
using**.

That last rule is enforced as a code invariant, not a promise:

```bash
./test/invariant.sh
```

It fails the build if any file under `src/` names an affiliate tag, edits a URL
query string, concatenates a host literal into a URL, or builds an outbound
`/go/` link outside `src/deals.js` — the one file allowed to construct an
outbound URL, and the one that validates its shape first.

Turn the deals list off in Settings if you only want the checkout assist.

## What it will not do

- Bank login, OTP, PIN, card number, or CAPTCHA.
- Buying in the background, refreshing stock, or changing quantity, variant, or address.
- Placing the order when a card, UPI, or cash on delivery option is still the selected payment.
- Running on the bank's website.

## Check the checkout logic

The decisions are covered by a local fixture, not by placing a real order:

```bash
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  --headless=new --disable-gpu --dump-dom \
  "file://$(pwd)/test/fixture.html"
```

The page text should contain `PASS`.

Then check the attribution invariant:

```bash
./test/invariant.sh
```
