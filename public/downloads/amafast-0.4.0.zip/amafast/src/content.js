(function () {
  "use strict";

  var FRAME = Math.random().toString(36).slice(2);
  var timer = 0;
  var generation = 0;
  var highlighted = false;
  var host = null;

  function isTop() {
    try {
      return window.top === window;
    } catch (err) {
      return false;
    }
  }

  function readFlag() {
    try {
      var raw = sessionStorage.getItem("amafast");
      return raw ? JSON.parse(raw) : null;
    } catch (err) {
      return null;
    }
  }

  function writeFlag(partial) {
    try {
      var next = Object.assign({}, readFlag() || {}, partial || {}, { at: Date.now() });
      sessionStorage.setItem("amafast", JSON.stringify(next));
    } catch (err) {
      /* sessionStorage can be blocked; the service worker still tracks the run. */
    }
  }

  function flagIsFresh(flag) {
    if (!flag || flag.active === false) return false;
    return Date.now() - (flag.armedAt || flag.at || 0) < 3 * 60 * 1000;
  }

  function readProduct() {
    var asinInput = document.querySelector("#ASIN, input[name='ASIN']");
    var pathMatch = (location.pathname || "").match(/\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})/);
    var title = document.querySelector("#productTitle");
    var price = document.querySelector("#buybox .a-price .a-offscreen, #corePrice_feature_div .a-offscreen, #apex_desktop .a-offscreen");
    return {
      asin: (asinInput && asinInput.value) || (pathMatch && pathMatch[1]) || "",
      title: title ? title.textContent.replace(/\s+/g, " ").trim().slice(0, 140) : "",
      price: price ? price.textContent.replace(/\s+/g, " ").trim().slice(0, 40) : ""
    };
  }

  function onOrdersPage() {
    return /order-history|\/your-orders|\/orders(?:\?|$)/i.test(location.href);
  }

  function send(message) {
    return chrome.runtime.sendMessage(message);
  }

  function ensureOverlay() {
    if (!isTop() || !document.documentElement) return null;
    if (host && host.isConnected) return host.shadowRoot;
    host = document.createElement("div");
    host.id = "amafast-root";
    host.setAttribute("data-amafast", "1");
    host.style.setProperty("position", "fixed", "important");
    host.style.setProperty("left", "16px", "important");
    host.style.setProperty("bottom", "16px", "important");
    host.style.setProperty("z-index", "2147483647", "important");
    host.style.setProperty("width", "300px", "important");
    host.style.setProperty("display", "block", "important");
    var shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = [
      "<style>",
      ":host { all: initial; display: block; }",
      ".card { width: 300px;",
      "  box-sizing: border-box; padding: 12px 12px 10px; border-radius: 14px;",
      "  background: #1d1a16; color: #f6f3eb; font: 13px/1.35 ui-sans-serif, system-ui, sans-serif;",
      "  box-shadow: 0 10px 30px rgba(0,0,0,.28); }",
      ".row { display: flex; align-items: center; justify-content: space-between; gap: 8px; }",
      ".name { font-weight: 700; letter-spacing: .02em; }",
      ".sub, .status { color: #d9d1c3; margin-top: 6px; }",
      ".status { min-height: 1.35em; }",
      "button { font: inherit; border: 0; border-radius: 999px; padding: 5px 10px; cursor: pointer; }",
      ".switch { background: #0f6e56; color: #f6f3eb; }",
      ".switch.off { background: #5e584e; }",
      ".stop { background: #f6f3eb; color: #1d1a16; }",
      ".actions { display: flex; gap: 6px; }",
      ".deal { margin-top: 8px; padding-top: 8px; border-top: 1px solid #3a352d; color: #d9d1c3; }",
      ".deal b { color: #f6f3eb; }",
      ".deal a { color: #7fd3b8; }",
      "</style>",
      "<div class='card' role='status' aria-live='polite'>",
      "  <div class='row'><div class='name'>AmaFast</div><div class='actions'>",
      "    <button class='stop' id='stop' type='button' hidden>Stop</button>",
      "    <button class='stop' id='run' type='button'>Run checkout</button>",
      "    <button class='switch' id='switch' type='button'>On</button>",
      "  </div></div>",
      "  <div class='sub' id='sub'></div>",
      "  <div class='status' id='status'></div>",
      "  <div class='deal' id='deal' hidden></div>",
      "</div>"
    ].join("");
    shadow.getElementById("switch").addEventListener("click", onToggle);
    shadow.getElementById("stop").addEventListener("click", onStop);
    shadow.getElementById("run").addEventListener("click", onRun);
    document.documentElement.appendChild(host);
    return shadow;
  }

  var settingsCache = {
    enabled: true,
    testMode: false,
    preferredBank: "",
    returnToOrders: true
  };
  var lastRun = null;

  function loadSettings() {
    chrome.storage.local.get("settings").then(function (stored) {
      settingsCache = Object.assign({}, settingsCache, stored.settings || {});
      if (isTop()) paint(settingsCache, lastRun);
    }).catch(function () {});
  }

  function paint(settings, run) {
    lastRun = run || null;
    if (settings) settingsCache = Object.assign({}, settingsCache, settings);
    var shadow = ensureOverlay();
    if (!shadow) return;
    var enabled = !settings || settings.enabled !== false;
    var toggle = shadow.getElementById("switch");
    var stop = shadow.getElementById("stop");
    var sub = shadow.getElementById("sub");
    var status = shadow.getElementById("status");
    toggle.textContent = enabled ? "On" : "Off";
    toggle.classList.toggle("off", !enabled);
    var active = !!(run && run.active);
    stop.hidden = !active;
    shadow.getElementById("run").hidden = !enabled;
    if (!enabled) {
      sub.textContent = "Off. Buy Now behaves as usual.";
      status.textContent = "";
      return;
    }
    if (settings && settings.testMode) {
      sub.textContent = "Test mode. Buy Now selects Internet Banking, then stops before placing the order.";
    } else if (settings && settings.returnToOrders === false) {
      sub.textContent = "Buy Now selects Internet Banking and leaves the bank page for you. AmaFast never signs in.";
    } else {
      sub.textContent = "Buy Now selects Internet Banking and a bank, skips bank sign-in, then opens Your Orders so you can pay your way.";
    }
    status.textContent = active && run.detail
      ? run.detail
      : "Loaded. Click Buy Now, or press Run checkout.";
  }

  /* IndiaOffers price/offer line for this exact product.
   *
   * Information only. It does not redirect, does not gate checkout, and links
   * to the deal page rather than the /go/ redirect — the user is already on
   * this product page, so routing them through an affiliate link here would be
   * claiming a referral we did not make. */
  function showDeal(deal) {
    var shadow = ensureOverlay();
    if (!shadow) return;
    var box = shadow.getElementById("deal");
    if (!box) return;
    box.replaceChildren();

    var line = document.createElement("div");
    line.appendChild(document.createTextNode("IndiaOffers: "));
    if (typeof deal.price === "number") {
      var price = document.createElement("b");
      price.textContent = "\u20B9" + deal.price.toLocaleString("en-IN");
      line.appendChild(price);
    }
    if (typeof deal.discountPct === "number") {
      line.appendChild(document.createTextNode(" \u00B7 " + deal.discountPct + "% off"));
    }
    box.appendChild(line);

    if (deal.bestOffer) {
      var offer = document.createElement("div");
      offer.textContent = deal.bestOffer;
      box.appendChild(offer);
    }
    if (deal.dealPage) {
      var link = document.createElement("a");
      link.href = deal.dealPage;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = "Offer details";
      box.appendChild(link);
    }
    box.hidden = false;
  }

  function loadDeal() {
    if (!isTop()) return;
    var product = readProduct();
    if (!product.asin) return;
    send({ type: "dealForAsin", asin: product.asin }).then(function (result) {
      if (result && result.deal) showDeal(result.deal);
    }).catch(function () {});
  }

  async function onToggle() {
    var state = await send({ type: "getState" });
    var enabled = !(state.settings && state.settings.enabled);
    await send({ type: "saveSettings", settings: { enabled: enabled } });
    if (!enabled) {
      writeFlag({ active: false });
      await send({ type: "stop", reason: "Turned off. Buy Now will behave as usual." });
    }
    paint(Object.assign({}, state.settings, { enabled: enabled }), enabled ? state.run : null);
  }

  async function onStop() {
    writeFlag({ active: false });
    var run = await send({ type: "stop", reason: "Stopped before the order was finished. You can complete checkout yourself." });
    paint(settingsCache, run);
  }

  function armNow() {
    if (settingsCache.enabled === false) return false;
    var pending = readFlag();
    /* Re-clicking Buy Now after an order is already in flight must not start a
       second run. */
    if (flagIsFresh(pending) && pending.submitted) return false;
    var product = readProduct();
    writeFlag({
      active: true,
      armedAt: Date.now(),
      submitted: false,
      product: product,
      testMode: !!settingsCache.testMode,
      preferredBank: settingsCache.preferredBank || ""
    });
    send({ type: "arm", product: product }).catch(function () {});
    start();
    paint(settingsCache, {
      active: true,
      detail: "Buy Now registered. Waiting for Amazon checkout."
    });
    return true;
  }

  function onRun() {
    var button = AmaFastEngine.findBuyNowButton(document);
    if (!armNow()) return;
    if (!button) return;
    var wrap = button.closest && button.closest(".a-button");
    var input = button.matches && button.matches("input, button")
      ? button
      : (wrap && wrap.querySelector("#buy-now-button, input[name='submit.buy-now'], input.a-button-input, button"));
    if (input && !input.disabled) input.click();
    else button.click();
  }

  async function acquireLock() {
    var data = await chrome.storage.session.get("lock");
    var lock = data.lock;
    var now = Date.now();
    if (lock && lock.token !== FRAME && now - lock.at < 1200) return false;
    await chrome.storage.session.set({ lock: { token: FRAME, at: now } });
    return true;
  }

  function watchFrames(run) {
    if (!run || !run.submitted) return;
    document.querySelectorAll("iframe").forEach(function (iframe) {
      try {
        var href = iframe.contentWindow.location.href;
        if (href && href !== "about:blank" && AmaFastEngine.isAmazonUrl(href)) {
          iframe.setAttribute("data-amafast-seen", "amazon");
        }
      } catch (err) {
        if (iframe.getAttribute("data-amafast-seen") === "amazon") {
          iframe.setAttribute("data-amafast-seen", "left");
          send({ type: "leftCheckout" });
        }
      }
    });
  }

  function highlightRevise() {
    AmaFastEngine.findReviseControls(document).forEach(function (el, index) {
      el.style.outline = "3px solid #0f6e56";
      el.style.outlineOffset = "2px";
      if (!highlighted && index === 0 && el.scrollIntoView) {
        el.scrollIntoView({ block: "center", inline: "nearest" });
      }
    });
    highlighted = true;
  }

  async function tick(token) {
    if (token !== generation) return;
    var state;
    try {
      state = await send({ type: "getState" });
    } catch (err) {
      timer = window.setTimeout(function () { tick(token); }, 700);
      return;
    }
    if (!state) return;
    var settings = state.settings || { enabled: true };
    var run = state.run;
    var flag = readFlag();
    if (flag && flag.submitted && run && run.active && !run.submitted) {
      run = await send({ type: "patch", patch: { submitted: true, code: "PLACE", phase: "submitted" } });
    }
    paint(settings, run);
    if (!settings.enabled) return;
    var mine = run && run.active && run.tabId === state.tabId;
    if (!mine) {
      if (flagIsFresh(flag)) {
        send({ type: "arm", product: flag.product || readProduct() });
        timer = window.setTimeout(function () { tick(token); }, 200);
      }
      return;
    }
    if (Date.now() > run.expiresAt) {
      writeFlag({ active: false });
      await send({ type: "stop", reason: "Timed out. Finish checkout yourself." });
      return;
    }
    if (isTop()) watchFrames(run);
    var mode = (run.phase === "orders" || onOrdersPage()) ? "orders" : "checkout";
    var decision;
    try {
      decision = AmaFastEngine.decide(document, {
        testMode: !!settings.testMode,
        preferredBank: settings.preferredBank || "",
        attempts: run.attempts,
        submitted: !!run.submitted,
        chosenBank: run.chosenBank || "",
        reviseOpened: !!run.reviseOpened,
        phase: run.phase,
        mode: mode
      });
    } catch (err) {
      await send({ type: "stop", reason: "AmaFast hit an unexpected page and stopped. Finish checkout yourself." });
      return;
    }
    if (decision.action === "idle" && run.active) {
      decision = {
        action: "wait",
        phase: run.phase || "armed",
        detail: "Buy Now registered. Waiting for Amazon checkout."
      };
    }
    if (decision.action === "wait" && decision.detail && run.detail !== decision.detail) {
      send({ type: "patch", patch: { phase: decision.phase || run.phase, detail: decision.detail } }).catch(function () {});
    }
    var paymentKind = decision.kind === "netbanking" || decision.kind === "bank" || decision.kind === "otherBanks" || decision.kind === "more" || decision.kind === "paymentContinue" || decision.kind === "place";
    if (isTop() && !run.submitted && !run.driveFailed) {
      send({ type: "drivePayment" }).catch(function () {});
    }
    if (paymentKind && !run.driveFailed) {
      timer = window.setTimeout(function () { tick(token); }, 500);
      return;
    }
    if (decision.action === "idle" || decision.action === "wait") {
      if (mode === "orders") highlightRevise();
      timer = window.setTimeout(function () { tick(token); }, decision.action === "idle" ? 500 : 250);
      return;
    }
    if (decision.action === "stop") {
      writeFlag({ active: false });
      var stopped = await send({
        type: "patch",
        patch: { active: false, phase: decision.phase, code: decision.code, detail: decision.detail }
      });
      paint(settings, stopped);
      return;
    }
    if (!(await acquireLock())) {
      timer = window.setTimeout(function () { tick(token); }, 250);
      return;
    }
    var attempts = Object.assign({}, run.attempts || {});
    if (decision.attemptKey) attempts[decision.attemptKey] = (attempts[decision.attemptKey] || 0) + 1;
    var update = {
      phase: decision.final ? "placing" : decision.phase,
      code: decision.code,
      detail: decision.detail,
      attempts: attempts,
      chosenBank: decision.kind === "bank" ? decision.label : (run.chosenBank || "")
    };
    if (decision.kind === "revise") update.reviseOpened = true;
    /* The attempt counter is recorded before the click so shouldBringBack()
       still works if this frame navigates away mid-click; submitted waits
       until the click is known to have landed. */
    writeFlag({ active: true, chosenBank: update.chosenBank });
    await send({ type: "patch", patch: update });
    var acted = decision.action === "select"
      ? AmaFastEngine.applySelect(decision.target, decision.value)
      : AmaFastEngine.activate(decision.target, decision.kind);
    if (decision.final) {
      if (acted) {
        writeFlag({ submitted: true });
        await send({ type: "patch", patch: { submitted: true, phase: "submitted" } });
      } else {
        await send({
          type: "patch",
          patch: {
            phase: "payment",
            detail: "The place-order button did not accept the click. Trying once more."
          }
        });
      }
    }
    timer = window.setTimeout(function () { tick(token); }, 400);
  }

  function start() {
    generation += 1;
    var token = generation;
    window.clearTimeout(timer);
    timer = window.setTimeout(function () { tick(token); }, 150);
  }

  function armFromEvent(event) {
    if (!isTop()) return;
    if (event.submitter && AmaFastEngine.findBuyNowTarget(event.submitter)) {
      armNow();
      return;
    }
    var path = event.composedPath ? event.composedPath() : [event.target];
    for (var i = 0; i < path.length; i += 1) {
      if (AmaFastEngine.findBuyNowTarget(path[i])) {
        armNow();
        return;
      }
    }
  }

  document.addEventListener("pointerdown", armFromEvent, true);
  document.addEventListener("click", armFromEvent, true);
  document.addEventListener("submit", armFromEvent, true);

  window.addEventListener("pagehide", function () {
    if (isTop()) {
      if (!flagIsFresh(readFlag())) return;
      send({ type: "amazonHiding" }).catch(function () {});
      return;
    }
    send({ type: "frameHiding" }).catch(function () {});
  });

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area === "local" && changes.settings && changes.settings.newValue) {
      settingsCache = Object.assign({}, settingsCache, changes.settings.newValue);
      if (changes.settings.newValue.enabled === false) {
        writeFlag({ active: false });
        send({ type: "getState" }).then(function (state) {
          if (state && state.run && state.run.active) {
            return send({ type: "stop", reason: "Turned off. Buy Now will behave as usual." });
          }
          return null;
        }).catch(function () {});
      }
    }
    if (area === "session" && changes.run && changes.run.newValue && changes.run.newValue.active) {
      start();
    }
    if (isTop() && (area === "session" || area === "local")) {
      send({ type: "getState" }).then(function (state) {
        if (state) paint(state.settings, state.run);
      }).catch(function () {});
    }
  });

  function boot() {
    loadSettings();
    send({ type: "amazonAlive" }).catch(function () {});
    if (!isTop() && /\/checkout|\/gp\/buy\/|payselect|turbo|\/pay\//i.test(location.href)) {
      send({ type: "frameStillAmazon" }).catch(function () {});
    }
    var paintWhenReady = function () {
      if (isTop()) paint(settingsCache, lastRun);
      send({ type: "getState" }).then(function (state) {
        if (!state) return;
        if (state.settings) settingsCache = Object.assign({}, settingsCache, state.settings);
        if (isTop()) paint(state.settings, state.run);
        var run = state.run;
        var flag = readFlag();
        if ((run && run.active && run.tabId === state.tabId) || flagIsFresh(flag) || onOrdersPage()) start();
      }).catch(function () {
        if (flagIsFresh(readFlag()) || onOrdersPage()) start();
      });
    };
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", paintWhenReady, { once: true });
    } else {
      paintWhenReady();
    }
    loadDeal();
    if (isTop() && document.documentElement) {
      new MutationObserver(function () {
        if (!host || !host.isConnected) {
          host = null;
          paint(settingsCache, lastRun);
        }
      }).observe(document.documentElement, { childList: true });
    }
  }

  boot();
})();
