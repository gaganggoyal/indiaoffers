(function () {
  "use strict";

  var DEFAULTS = {
    enabled: true,
    testMode: false,
    preferredBank: "",
    returnToOrders: true,
    showDeals: true
  };

  var enabled = document.getElementById("enabled");
  var testMode = document.getElementById("testMode");
  var returnToOrders = document.getElementById("returnToOrders");
  var preferredBank = document.getElementById("preferredBank");
  var status = document.getElementById("status");
  var log = document.getElementById("log");

  function show(settings, run) {
    enabled.checked = settings.enabled !== false;
    testMode.checked = !!settings.testMode;
    returnToOrders.checked = settings.returnToOrders !== false;
    if (document.activeElement !== preferredBank) {
      preferredBank.value = settings.preferredBank || "";
    }
    status.textContent = run && run.detail ? run.detail : "Waiting for Buy Now on Amazon.in.";
    log.replaceChildren();
    ((run && run.log) || []).slice(-6).forEach(function (entry) {
      var item = document.createElement("li");
      item.textContent = entry.code;
      log.appendChild(item);
    });
  }

  async function read() {
    var stored = await chrome.storage.local.get("settings");
    var session = await chrome.storage.session.get("run");
    return {
      settings: Object.assign({}, DEFAULTS, stored.settings || {}),
      run: session.run || null
    };
  }

  async function write(partial) {
    var state = await read();
    var settings = Object.assign({}, state.settings, partial);
    await chrome.storage.local.set({ settings: settings });
    if (partial.enabled === false && state.run && state.run.active) {
      chrome.runtime.sendMessage({ type: "stop", reason: "Turned off. Buy Now will behave as usual." });
    }
    show(settings, state.run);
  }

  read().then(function (state) {
    show(state.settings, state.run);
  });

  enabled.addEventListener("change", function () {
    write({ enabled: enabled.checked });
  });
  testMode.addEventListener("change", function () {
    write({ testMode: testMode.checked });
  });
  returnToOrders.addEventListener("change", function () {
    write({ returnToOrders: returnToOrders.checked });
  });
  preferredBank.addEventListener("change", function () {
    write({ preferredBank: preferredBank.value.trim() });
  });

  document.getElementById("orders").addEventListener("click", function () {
    chrome.tabs.create({ url: "https://www.amazon.in/gp/your-account/order-history?ref_=amafast" });
  });
  document.getElementById("options").addEventListener("click", function () {
    chrome.runtime.openOptionsPage();
  });

  /* ---- IndiaOffers deals -------------------------------------------------
   * Feed content is remote, so every node is built with textContent rather
   * than innerHTML, and the click hands the background a /go/ URL it
   * re-validates before opening. The popup never constructs a merchant link.
   * --------------------------------------------------------------------- */

  var dealsList = document.getElementById("dealsList");
  var dealsEmpty = document.getElementById("dealsEmpty");

  function rupees(value) {
    return typeof value === "number" ? "\u20B9" + value.toLocaleString("en-IN") : "";
  }

  function dealNode(deal) {
    var item = document.createElement("li");
    var button = document.createElement("button");
    button.type = "button";
    button.className = "deal";

    if (deal.image) {
      var img = document.createElement("img");
      img.src = deal.image;
      img.alt = "";
      button.appendChild(img);
    }

    var body = document.createElement("span");
    body.className = "deal-body";

    var title = document.createElement("span");
    title.className = "deal-title";
    title.textContent = deal.title || "Deal";
    body.appendChild(title);

    var meta = document.createElement("span");
    meta.className = "deal-meta";
    if (typeof deal.price === "number") {
      meta.appendChild(document.createTextNode(rupees(deal.price) + " "));
    }
    if (typeof deal.mrp === "number" && deal.mrp > (deal.price || 0)) {
      var mrp = document.createElement("span");
      mrp.className = "deal-mrp";
      mrp.textContent = rupees(deal.mrp);
      meta.appendChild(mrp);
    }
    if (typeof deal.discountPct === "number") {
      meta.appendChild(document.createTextNode(" \u00B7 " + deal.discountPct + "% off"));
    }
    if (meta.childNodes.length) body.appendChild(meta);

    if (deal.bestOffer) {
      var offer = document.createElement("span");
      offer.className = "deal-meta deal-offer";
      offer.textContent = deal.bestOffer;
      body.appendChild(offer);
    }

    button.appendChild(body);
    button.addEventListener("click", function () {
      chrome.runtime.sendMessage({ type: "openDeal", go: deal.go });
    });
    item.appendChild(button);
    return item;
  }

  function paintDeals(deals, settings) {
    var section = document.getElementById("dealsSection");
    if (settings && settings.showDeals === false) {
      section.hidden = true;
      return;
    }
    section.hidden = false;
    dealsList.replaceChildren();
    (deals || []).slice(0, 25).forEach(function (deal) {
      dealsList.appendChild(dealNode(deal));
    });
    dealsEmpty.hidden = (deals || []).length > 0;
    if (!(deals || []).length) {
      dealsEmpty.textContent = "No deals right now. Check indiaoffers.in.";
    }
  }

  function paintUpdate(latest) {
    var banner = document.getElementById("update");
    var installed = chrome.runtime.getManifest().version;
    if (!latest || !latest.url || !AmaFastDealsVersion.isNewer(latest.version, installed)) {
      banner.hidden = true;
      return;
    }
    banner.textContent = "Update available \u2014 v" + latest.version
      + (latest.notes ? ". " + latest.notes : "") + " Get it \u2192";
    banner.href = latest.url;
    banner.hidden = false;
  }

  /* A store link the user clicks from inside our own popup: we are the reason
     they are heading to Amazon, so the referral is ours to make. */
  function paintBrowse(browse) {
    var button = document.getElementById("browse");
    if (!browse || !browse.go) {
      button.hidden = true;
      return;
    }
    button.textContent = browse.label + " \u2192";
    button.onclick = function () {
      chrome.runtime.sendMessage({ type: "openDeal", go: browse.go });
    };
    button.hidden = false;
  }

  function loadDeals(message) {
    chrome.runtime.sendMessage({ type: message || "getDeals" }).then(function (result) {
      paintUpdate(result && result.latest);
      paintBrowse(result && result.browse);
      read().then(function (state) {
        paintDeals(result && result.deals, state.settings);
      });
    }).catch(function () {
      dealsEmpty.hidden = false;
      dealsEmpty.textContent = "Could not reach IndiaOffers.";
    });
  }

  document.getElementById("refresh").addEventListener("click", function () {
    dealsEmpty.hidden = false;
    dealsEmpty.textContent = "Refreshing\u2026";
    loadDeals("refreshDeals");
  });

  loadDeals("getDeals");
  chrome.runtime.sendMessage({ type: "dealsSeen" }).catch(function () {});

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area !== "session" && area !== "local") return;
    read().then(function (state) {
      show(state.settings, state.run);
    });
    if (area === "local" && changes.dealsCache && changes.dealsCache.newValue) {
      read().then(function (state) {
        paintDeals(changes.dealsCache.newValue.deals, state.settings);
      });
    }
  });
})();
