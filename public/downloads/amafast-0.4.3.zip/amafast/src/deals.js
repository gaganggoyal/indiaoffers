"use strict";

/* IndiaOffers deals feed.
 *
 * Attribution invariant: this extension never builds an Amazon URL and never
 * writes, reads or rewrites an affiliate tag. The only outbound link it can
 * produce is the /go/ path the feed supplies, which indiaoffers.in redirects —
 * the tag is attached there, on a click the user made against our own deal
 * listing. outboundUrl() enforces that shape, so neither a malformed feed nor
 * a hostile one can turn a feed value into a merchant link.
 */

var AmaFastDeals = (function () {
  var ORIGIN = "https://indiaoffers.in";
  var FEED = ORIGIN + "/api/extension/deals.json";
  var CACHE_KEY = "dealsCache";
  var TTL_MS = 20 * 60 * 1000;
  var GO_RE = /^\/go\/[a-z]\/[A-Za-z0-9_.~-]{1,64}$/;
  var DEAL_RE = /^\/deal\/[A-Za-z0-9_.~-]{1,160}$/;

  /* The two functions that decide what this extension is allowed to open. */
  function outboundUrl(go) {
    return GO_RE.test(String(go || "")) ? ORIGIN + go : null;
  }

  function dealPageUrl(path) {
    return DEAL_RE.test(String(path || "")) ? ORIGIN + path : null;
  }

  function num(value) {
    /* Number(null) and Number("") are both 0, which would render a real deal
       as "\u20B90". A missing price stays missing. */
    if (value === null || value === undefined || value === "") return null;
    var n = Number(value);
    return isFinite(n) ? n : null;
  }

  function text(value, max) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim().slice(0, max);
  }

  /* Feed content is remote data, so every field is re-validated here rather
     than trusted into the UI. A deal with no usable /go/ path is dropped. */
  function clean(raw) {
    if (!raw || typeof raw !== "object") return null;
    var go = outboundUrl(raw.go);
    if (!go) return null;
    var asin = /^[A-Z0-9]{10}$/.test(String(raw.asin || "").toUpperCase())
      ? String(raw.asin).toUpperCase()
      : "";
    return {
      id: text(raw.id, 64),
      title: text(raw.title, 140),
      store: text(raw.store, 40),
      asin: asin,
      image: /^https:\/\//.test(String(raw.image || "")) ? String(raw.image).slice(0, 400) : "",
      price: num(raw.price),
      mrp: num(raw.mrp),
      discountPct: num(raw.discountPct),
      truePrice: num(raw.truePrice),
      bestOffer: text(raw.bestOffer, 120),
      coupon: text(raw.coupon, 40),
      badge: text(raw.badge, 24),
      postedAt: text(raw.postedAt, 40),
      go: go,
      dealPage: dealPageUrl(raw.deal) || ""
    };
  }

  /* AmaFast installs from indiaoffers.in rather than the Chrome Web Store, so
     nothing updates it automatically. The feed names the current build and the
     popup tells the user when theirs is behind. */
  function cleanLatest(raw) {
    if (!raw || typeof raw !== "object") return null;
    var version = text(raw.version, 16);
    if (!/^\d+(\.\d+){0,3}$/.test(version)) return null;
    return {
      version: version,
      url: /^https:\/\/indiaoffers\.in\//.test(String(raw.url || "")) ? String(raw.url).slice(0, 200) : "",
      notes: text(raw.notes, 120)
    };
  }

  function isNewer(latest, installed) {
    var a = String(latest || "").split(".").map(Number);
    var b = String(installed || "").split(".").map(Number);
    for (var i = 0; i < Math.max(a.length, b.length); i += 1) {
      var x = a[i] || 0;
      var y = b[i] || 0;
      if (x !== y) return x > y;
    }
    return false;
  }

  /* What this deal adds that the Amazon page in front of the user does not.
     Zero means we have nothing to offer, and the in-page prompt stays hidden —
     sending someone to our site with no new information would only be moving
     the affiliate attribution. */
  function dealSaving(deal) {
    if (!deal) return 0;
    if (deal.bestOffer) return num(deal.bestSaving) || 0;
    var truePrice = num(deal.truePrice);
    var price = num(deal.price);
    if (truePrice !== null && price !== null && truePrice < price) return price - truePrice;
    return 0;
  }

  /* "Browse more deals on Amazon" — a store-level referral offered from our
     own popup, where the click genuinely starts with us. Validated through the
     same chokepoint as every deal link. */
  function cleanBrowse(raw) {
    if (!raw || typeof raw !== "object") return null;
    var go = outboundUrl(raw.go);
    var label = text(raw.label, 60);
    if (!go || !label) return null;
    return { label: label, store: text(raw.store, 40), go: go };
  }

  async function cached() {
    var stored = await chrome.storage.local.get(CACHE_KEY);
    return stored[CACHE_KEY] || null;
  }

  function fresh(cache) {
    return !!(cache && cache.fetchedAt && Date.now() - cache.fetchedAt < TTL_MS);
  }

  async function refresh(force) {
    var cache = await cached();
    if (!force && fresh(cache)) return cache;
    var headers = {};
    if (cache && cache.etag) headers["If-None-Match"] = cache.etag;
    var response;
    try {
      response = await fetch(FEED, { headers: headers, credentials: "omit" });
    } catch (err) {
      return cache;
    }
    if (response.status === 304 && cache) {
      cache.fetchedAt = Date.now();
      await chrome.storage.local.set({ dealsCache: cache });
      return cache;
    }
    if (!response.ok) return cache;
    var body;
    try {
      body = await response.json();
    } catch (err) {
      return cache;
    }
    var deals = (Array.isArray(body.deals) ? body.deals : []).map(clean).filter(Boolean);
    var next = {
      deals: deals,
      latest: cleanLatest(body.extension),
      browse: cleanBrowse(body.browse),
      updated: text(body.updated, 40),
      etag: response.headers.get("ETag") || "",
      fetchedAt: Date.now()
    };
    await chrome.storage.local.set({ dealsCache: next });
    return next;
  }

  async function byAsin(asin) {
    if (!/^[A-Z0-9]{10}$/.test(String(asin || "").toUpperCase())) return null;
    var want = String(asin).toUpperCase();
    var cache = await cached();
    if (!cache) return null;
    return cache.deals.filter(function (deal) { return deal.asin === want; })[0] || null;
  }

  /* Deals posted since the user last opened the popup — the badge count. */
  function unseen(cache, lastSeenAt) {
    if (!cache || !lastSeenAt) return 0;
    return cache.deals.filter(function (deal) {
      var at = Date.parse((deal.postedAt || "").replace(" ", "T") + "Z");
      return isFinite(at) && at > lastSeenAt;
    }).length;
  }

  return {
    ORIGIN: ORIGIN,
    refresh: refresh,
    cached: cached,
    byAsin: byAsin,
    unseen: unseen,
    isNewer: isNewer,
    dealSaving: dealSaving,
    cleanBrowse: cleanBrowse,
    cleanLatest: cleanLatest,
    outboundUrl: outboundUrl,
    dealPageUrl: dealPageUrl,
    clean: clean
  };
})();

if (typeof globalThis !== "undefined") globalThis.AmaFastDeals = AmaFastDeals;
