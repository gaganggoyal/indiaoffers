# AmaFast privacy

AmaFast is a local Chrome extension. It has no account, and the only server it
talks to is IndiaOffers.in, to download the public deals list (see below).

What stays on this browser:

- The on/off switch, test mode, the optional bank name, and whether to return to Your Orders. These are in `chrome.storage.local`.
- The current checkout attempt: phase name, error code, a short status line, and the product title, ASIN, and price shown on the product page. This is in `chrome.storage.session` and is discarded when the browser session ends.
- A same-tab flag in `sessionStorage` so a Buy Now click can continue onto Amazon's next page. It lives for a few minutes.
- The downloaded deals list, so the popup works offline between refreshes. It holds no personal data.

What AmaFast does not do:

- It does not read or store a bank user id, password, OTP, PIN, card number, CVV, or Amazon password.
- It does not read Amazon cookies or browsing history beyond the single checkout tab it was asked to finish.
- It does not send page contents, orders, products you view, or the bank name to any server.
- It does not run on bank websites.

## Deals from IndiaOffers.in

Every 20 minutes the extension downloads the public deals list from
`https://indiaoffers.in/api/extension/deals.json`. The request carries no
cookies and no information about you, the page you are on, or the product you
are looking at — it is the same list for everyone, and IndiaOffers.in learns
nothing from it beyond the fact that some browser asked for the file.

When a product page matches a deal, the price and bank offer shown in the
AmaFast card are matched **on your machine**, against the list already
downloaded. The product you are viewing is never sent anywhere.

Opening a deal from the AmaFast popup is a normal link click to
IndiaOffers.in, which records the click and forwards you to the store with an
affiliate link. We may earn a commission on what you buy through it, at no
extra cost to you. AmaFast never adds, removes or changes an affiliate tag on
a page you opened yourself — on a product page you reached on your own, it only
displays information and does not redirect you.

You can turn the deals list off entirely in the extension's settings.

## Permissions

The `tabs` permission is used only to notice when that checkout tab leaves Amazon.in, so the extension can open Your Orders without interacting with the bank page. The bank address is not saved.

Uninstalling the extension removes the saved settings. You can also clear them from the extension's settings page.
