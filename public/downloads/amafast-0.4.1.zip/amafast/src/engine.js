(function () {
  "use strict";

  var BANK_PHRASES = [
    "State Bank of India",
    "HDFC Bank",
    "ICICI Bank",
    "Axis Bank",
    "Kotak Mahindra Bank",
    "Punjab National Bank",
    "Bank of Baroda",
    "Union Bank of India",
    "Canara Bank",
    "IndusInd Bank",
    "IDFC FIRST Bank",
    "Yes Bank",
    "Indian Overseas Bank",
    "Central Bank of India",
    "Bank of Maharashtra",
    "Punjab & Sind Bank",
    "Jammu & Kashmir Bank",
    "Karur Vysya Bank",
    "Tamilnad Mercantile Bank",
    "South Indian Bank",
    "City Union Bank",
    "Karnataka Bank",
    "Standard Chartered",
    "Airtel Payments Bank",
    "Paytm Payments Bank",
    "India Post Payments Bank",
    "AU Small Finance Bank",
    "Federal Bank",
    "Indian Bank",
    "IDBI Bank",
    "DCB Bank",
    "RBL Bank",
    "Bandhan Bank",
    "UCO Bank",
    "Bank of India",
    "Union Bank",
    "Kotak",
    "HDFC",
    "ICICI",
    "Axis",
    "PNB",
    "SBI"
  ].sort(function (a, b) {
    return b.length - a.length;
  });

  var BANK_WORD_RES = BANK_PHRASES.map(function (name) {
    return new RegExp("(^|\\b)" + escapeReg(name) + "(\\b|$)", "i");
  });
  var BANK_LEAD_RES = BANK_PHRASES.map(function (name) {
    return new RegExp("^" + escapeReg(name) + "(?:\\b|$)", "i");
  });

  var NET_RE = /^(?:net\s*banking|internet\s*banking|pay\s+via\s+(?:net|internet)\s*banking|netbanking|नेट\s*बैंकिंग|इंटरनेट\s*बैंकिंग)(?!\w)/i;
  var ADDRESS_RE = /^(deliver to this address|use this address|ship to this address|इस पते पर डिलीवरी करें|इस पते पर पहुंचाएं)(?:[\s›»]|$)/i;
  var CONTINUE_RE = /^(continue|जारी रखें)(?:[\s›»]|$)/i;
  var PAYMENT_CONTINUE_RE = /^(use this payment method|continue with this payment method|confirm payment method|यह भुगतान विधि इस्तेमाल करें)\b/i;
  var PLACE_RE = /^(?:place your order(?: and pay)?|pay now|proceed to pay|proceed to bank|continue to bank|redirect to bank|अपना ऑर्डर प्लेस करें|ऑर्डर दें|ऑर्डर प्लेस करें)(?!\w)/i;
  var PAY_AMOUNT_RE = /^pay\s+(₹|rs\.?|inr)\b/i;
  var OTHER_BANKS_RE = /^(other banks?|all other banks?|all banks?|more banks?|see all banks?|view all banks?|show all banks?|select a bank|select bank|choose a bank|choose bank|अन्य बैंक)\b/i;
  var MORE_PAY_RE = /^(more ways to pay|other payment options|see all payment methods|more payment options|all payment methods|show more|another payment method|add a payment method|other methods|see more)\b/i;
  var PRIME_DECLINE_RE = /^(no thanks|no, thanks|not now|continue without prime|skip|no i don't want prime benefits|i don't want prime)\b/i;
  var PRIME_ACCEPT_RE = /\b(join prime|start your .*free trial|free trial|try prime|start membership)\b/i;
  var REVISE_CLICK_RE = /^(revise payment(?: method)?|change payment method|change payment|भुगतान विधि बदलें)\b/i;
  var REVISE_ANY_RE = /^(revise payment(?: method)?|change payment method|change payment|complete (?:your )?payment|retry payment(?: method)?|pay now|भुगतान विधि बदलें)\b/i;
  var OTHER_PAYMENT_RE = /\b(credit card|debit card|upi|cash on delivery|amazon pay|pay later|emi|cod)\b/i;
  var STOP_TAGS = { BODY: 1, HTML: 1 };

  function norm(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function escapeReg(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  /* One scan is one synchronous pass over a stable DOM, so anything derived
     from an element can be cached until the next pass begins. */
  var scanToken = 0;

  function beginScan() {
    scanToken += 1;
  }

  function memoPerScan(fn) {
    var token = -1;
    var cache = null;
    return function (el) {
      if (token !== scanToken) {
        token = scanToken;
        cache = new WeakMap();
      }
      if (!el || typeof el !== "object") return fn(el);
      var hit = cache.get(el);
      if (hit === undefined) {
        hit = fn(el);
        cache.set(el, hit);
      }
      return hit;
    };
  }

  function docOf(root) {
    if (root && root.nodeType === 9) return root;
    return (root && root.ownerDocument) || document;
  }

  function isAmazonUrl(url) {
    try {
      var host = new URL(url).hostname.toLowerCase();
      return host === "amazon.in" || host.endsWith(".amazon.in");
    } catch (err) {
      return false;
    }
  }

  function shouldBringBack(run) {
    if (!run) return false;
    if (run.phase === "orders" || run.phase === "stopped" || run.phase === "test_stopped" || run.phase === "at_bank") {
      return false;
    }
    if (run.submitted) return true;
    var attempts = run.attempts || {};
    if (attempts.place > 0 || attempts.paymentContinue > 0) return true;
    if (attempts.bank > 0 && (run.phase === "bank_selected" || run.phase === "payment" || run.phase === "review" || run.phase === "submitted" || run.phase === "leaving_bank")) {
      return true;
    }
    return false;
  }

  function inIgnoredRegion(el) {
    var node = el;
    while (node) {
      if (node.nodeType === 1) {
        if (node.id === "amafast-root") return true;
        if (node.matches && node.matches("header, footer, nav, #navbar, #navFooter, #rhf")) return true;
      }
      var root = node.getRootNode && node.getRootNode();
      if (root && root.host) {
        node = root.host;
        continue;
      }
      node = node.parentElement;
    }
    return false;
  }

  var scopeToken = -1;
  var scopeRoot = null;
  var scopeList = null;

  function scopesOf(root) {
    if (scopeToken === scanToken && scopeRoot === root) return scopeList;
    var list = [];
    (function scan(scope) {
      if (!scope || !scope.querySelectorAll || list.indexOf(scope) !== -1) return;
      list.push(scope);
      scope.querySelectorAll("*").forEach(function (el) {
        if (el.shadowRoot) scan(el.shadowRoot);
      });
    })(root);
    scopeToken = scanToken;
    scopeRoot = root;
    scopeList = list;
    return list;
  }

  function queryAllDeep(root, selector) {
    var out = [];
    scopesOf(root).forEach(function (scope) {
      scope.querySelectorAll(selector).forEach(function (el) {
        out.push(el);
      });
    });
    return out;
  }

  function computeVisible(el) {
    if (!el || el.nodeType !== 1 || el.disabled) return false;
    if (el.hidden || el.getAttribute("aria-hidden") === "true") return false;
    var view = docOf(el).defaultView || window;
    var style = view.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
    var rect = el.getBoundingClientRect();
    return rect.width > 1 && rect.height > 1;
  }

  var visible = memoPerScan(computeVisible);

  function controlVisible(el) {
    if (!el || inIgnoredRegion(el)) return false;
    if (visible(el)) return true;
    var wrap = el.closest && el.closest("button, .a-button, [role='button'], label");
    return !!(wrap && visible(wrap));
  }

  function area(el) {
    var rect = el.getBoundingClientRect();
    var size = rect.width * rect.height;
    return size || Number.MAX_SAFE_INTEGER;
  }

  function computeLabels(el) {
    var bits = [];
    ["aria-label", "title", "alt"].forEach(function (attr) {
      var value = el.getAttribute && el.getAttribute(attr);
      if (value) bits.push(norm(value));
    });
    if (el.tagName === "INPUT" && (el.type === "submit" || el.type === "button") && el.value) {
      bits.push(norm(el.value));
    }
    if (el.tagName === "IMG" && el.alt) bits.push(norm(el.alt));
    var image = el.querySelector && el.querySelector("img[alt]");
    if (image) bits.push(norm(image.getAttribute("alt")));
    var text = norm(el.innerText || "");
    if (text && text.length <= 90) bits.push(text);
    return bits.filter(Boolean);
  }

  /* Callers only ever filter/map the result, so handing back the cached array
     is safe. */
  var labelsOf = memoPerScan(computeLabels);

  function bannedLabel(text) {
    return /not available|unavailable|cannot|can't|disabled|no longer/i.test(text);
  }

  function computeClickable(el) {
    var tag = el.tagName;
    if (tag === "BUTTON" || tag === "A" || tag === "INPUT" || tag === "LABEL" || tag === "SELECT") return true;
    var role = el.getAttribute && el.getAttribute("role");
    if (role === "button" || role === "radio" || role === "option" || role === "link" || role === "tab") return true;
    if (el.classList && (el.classList.contains("a-button") || el.classList.contains("a-button-text"))) return true;
    if (typeof el.tabIndex === "number" && el.tabIndex >= 0) return true;
    if (tag === "SPAN" || tag === "LI" || tag === "DIV" || tag === "P" || tag === "H2" || tag === "H3" || tag === "H4") {
      var text = norm(el.innerText || el.textContent || "");
      if (!text || text.length > 80) return false;
      var hits = text.match(/net\s*banking|internet\s*banking|upi|cash on delivery|credit|debit|emi|buy now|add to cart|नेट\s*बैंकिंग/gi);
      return !(hits && hits.length > 1);
    }
    return false;
  }

  var isClickable = memoPerScan(computeClickable);

  function byLabel(root, re) {
    return queryAllDeep(root, "button, a, input, label, span, li, div, [role='button'], [role='radio'], [role='option'], [role='link']")
      .filter(function (el) {
        return controlVisible(el) && isClickable(el);
      })
      .map(function (el) {
        var labels = labelsOf(el).filter(function (text) {
          return text.length <= 90 && re.test(text) && !bannedLabel(text);
        });
        labels.sort(function (a, b) {
          return a.length - b.length;
        });
        return labels.length ? { el: el, text: labels[0] } : null;
      })
      .filter(Boolean)
      .sort(function (a, b) {
        return area(a.el) - area(b.el) || a.text.length - b.text.length;
      });
  }

  function firstMatch(root, re) {
    var found = byLabel(root, re);
    return found.length ? found[0].el : null;
  }

  var netToken = -1;
  var netRoot = null;
  var netEl = null;

  /* nearNetBanking() runs per candidate control, so without this the whole
     document was rescanned once for every bank button on the page. */
  function netBankingControl(root) {
    if (netToken === scanToken && netRoot === root) return netEl;
    netToken = scanToken;
    netRoot = root;
    netEl = firstMatch(root, NET_RE);
    return netEl;
  }

  function labelFor(el, re) {
    if (!el) return "";
    var labels = labelsOf(el).filter(function (text) {
      return !re || re.test(text);
    });
    labels.sort(function (a, b) {
      return a.length - b.length;
    });
    return labels[0] || "";
  }

  function attemptsOf(ctx) {
    var base = {
      address: 0,
      delivery: 0,
      morePayments: 0,
      netBanking: 0,
      otherBanks: 0,
      bank: 0,
      paymentContinue: 0,
      place: 0,
      prime: 0,
      revise: 0
    };
    var extra = (ctx && ctx.attempts) || {};
    Object.keys(base).forEach(function (key) {
      if (typeof extra[key] === "number") base[key] = extra[key];
    });
    return base;
  }

  function result(action, fields) {
    var out = {
      action: action,
      code: "",
      phase: "",
      detail: "",
      label: "",
      kind: "",
      attemptKey: "",
      value: "",
      final: false,
      target: null
    };
    Object.keys(fields || {}).forEach(function (key) {
      out[key] = fields[key];
    });
    return out;
  }

  function idle() {
    return result("idle", { code: "IDLE", phase: "idle", detail: "" });
  }

  function wait(phase, detail) {
    return result("wait", { code: "WAIT", phase: phase, detail: detail });
  }

  function stop(code, detail) {
    return result("stop", {
      code: code,
      phase: code === "TEST_STOP" ? "test_stopped" : "stopped",
      detail: detail
    });
  }

  function click(el, kind, code, phase, detail, attemptKey, final) {
    return result("click", {
      target: el,
      kind: kind,
      code: code,
      phase: phase,
      detail: detail,
      label: labelFor(el) || kind,
      attemptKey: attemptKey,
      final: !!final
    });
  }

  function isCaptcha(root) {
    var doc = docOf(root);
    var href = (doc.location && doc.location.href) || "";
    if (/validateCaptcha|\/errors\/validateCaptcha/i.test(href)) return true;
    return !!queryAllDeep(doc, "form[action*='validateCaptcha'], #captchacharacters, input[name='cvf_captcha_input']").length;
  }

  function isSignIn(root) {
    var doc = docOf(root);
    var href = (doc.location && doc.location.href) || "";
    if (/\/ap\/signin/i.test(href)) return true;
    var email = doc.querySelector && doc.querySelector("#ap_email, form[name='signIn'] input[name='email']");
    return !!(email && controlVisible(email));
  }

  function onOrdersPage(root) {
    var href = (docOf(root).location && docOf(root).location.href) || "";
    return /order-history|\/your-orders|\/orders(?:\?|$)/i.test(href);
  }

  function isBankText(text) {
    var value = norm(text);
    if (!value || value.length > 60) return false;
    if (OTHER_PAYMENT_RE.test(value)) return false;
    if (/^(select|choose|pick|search|other|popular|all)\b/i.test(value)) return false;
    return BANK_WORD_RES.some(function (re) {
      return re.test(value);
    });
  }

  function matchesPreferred(text, preferred) {
    var want = norm(preferred).toLowerCase();
    var have = norm(text).toLowerCase();
    if (!want || !have) return false;
    if (have.indexOf(want) !== -1 || want.indexOf(have) !== -1) return true;
    var groups = [
      ["sbi", "state bank of india"],
      ["hdfc", "hdfc bank"],
      ["icici", "icici bank"],
      ["axis", "axis bank"],
      ["pnb", "punjab national bank"],
      ["kotak", "kotak mahindra bank", "kotak"]
    ];
    return groups.some(function (names) {
      var prefMatch = names.some(function (name) { return name === want; });
      return prefMatch && names.some(function (name) { return have.indexOf(name) !== -1; });
    });
  }

  function usableSelect(el) {
    if (!el || el.tagName !== "SELECT" || el.disabled || inIgnoredRegion(el)) return false;
    var style = (docOf(el).defaultView || window).getComputedStyle(el);
    return style.display !== "none" && style.visibility !== "hidden";
  }

  function bankSelects(root) {
    return queryAllDeep(root, "select").filter(function (sel) {
      if (!usableSelect(sel)) return false;
      var banks = 0;
      Array.prototype.forEach.call(sel.options || [], function (opt) {
        if (isBankText(opt.textContent || "")) banks += 1;
      });
      return banks > 0;
    });
  }

  function selectedBankName(root) {
    var found = "";
    bankSelects(root).some(function (sel) {
      var opt = sel.selectedOptions && sel.selectedOptions[0];
      var text = norm(opt && opt.textContent);
      if (text && isBankText(text)) {
        found = text;
        return true;
      }
      return false;
    });
    if (found) return found;
    var controls = queryAllDeep(root, "button, a, label, [role='radio'], [role='option'], input[type='radio']")
      .filter(function (el) { return controlVisible(el) && !inIgnoredRegion(el); });
    controls.some(function (el) {
      var text = labelsOf(el).filter(isBankText)[0];
      if (!text) return false;
      var on = el.checked
        || el.getAttribute("aria-checked") === "true"
        || el.getAttribute("aria-selected") === "true"
        || el.getAttribute("aria-pressed") === "true"
        || (el.classList && (el.classList.contains("selected") || el.classList.contains("a-button-selected")))
        || el.getAttribute("data-selected") === "true";
      var parent = el.parentElement;
      if (!on && parent) {
        on = parent.getAttribute("aria-selected") === "true" || (parent.classList && parent.classList.contains("selected"));
      }
      if (on) {
        found = text;
        return true;
      }
      return false;
    });
    return found;
  }

  function radioFor(el) {
    if (!el) return null;
    if (el.matches && el.matches("input[type='radio'], [role='radio']")) return el;
    var label = el.closest && el.closest("label");
    if (label) {
      if (label.htmlFor) {
        var pointed = docOf(el).getElementById(label.htmlFor);
        if (pointed && (pointed.type === "radio" || pointed.getAttribute("role") === "radio")) return pointed;
      }
      var inner = label.querySelector("input[type='radio'], [role='radio']");
      if (inner) return inner;
    }
    var node = el;
    for (var i = 0; i < 8 && node; i += 1) {
      var radios = node.querySelectorAll ? node.querySelectorAll("input[type='radio'], [role='radio']") : [];
      if (radios.length === 1) return radios[0];
      node = node.parentElement;
    }
    return null;
  }

  function rowText(el) {
    var radio = el && el.matches && el.matches("input[type='radio'], [role='radio']") ? el : radioFor(el);
    var node = radio || el;
    for (var i = 0; i < 8 && node; i += 1) {
      var radios = node.querySelectorAll ? node.querySelectorAll("input[type='radio'], [role='radio']") : [];
      if (radios.length === 1) {
        var text = norm(node.innerText || "");
        if (text && text.length <= 120) return text;
      }
      node = node.parentElement;
    }
    return labelFor(el);
  }

  function netBankingSelected(root) {
    var matches = byLabel(root, NET_RE);
    return matches.some(function (item) {
      var radio = radioFor(item.el);
      if (radio && (radio.checked || radio.getAttribute("aria-checked") === "true")) return true;
      var el = item.el;
      return el.getAttribute("aria-pressed") === "true" || el.getAttribute("aria-checked") === "true" || el.getAttribute("aria-selected") === "true";
    });
  }

  function otherPaymentSelected(root) {
    var radios = queryAllDeep(root, "input[type='radio'], [role='radio']").filter(controlVisible);
    return radios.some(function (radio) {
      var on = radio.checked || radio.getAttribute("aria-checked") === "true";
      if (!on) return false;
      var text = rowText(radio);
      if (NET_RE.test(text)) return false;
      return OTHER_PAYMENT_RE.test(text);
    });
  }

  function nearNetBanking(root, el) {
    var net = netBankingControl(root);
    if (!net) return true;
    var node = el && el.parentElement;
    for (var i = 0; i < 20 && node && !STOP_TAGS[node.tagName]; i += 1) {
      if (node.contains(net)) return true;
      node = node.parentElement;
    }
    return false;
  }

  function leadingBank(text) {
    var value = norm(text);
    if (!value || value.length > 60 || OTHER_PAYMENT_RE.test(value)) return "";
    var found = "";
    for (var i = 0; i < BANK_LEAD_RES.length; i += 1) {
      if (BANK_LEAD_RES[i].test(value)) {
        found = BANK_PHRASES[i];
        break;
      }
    }
    if (!found) return "";
    if (isBankText(value.slice(found.length))) return "";
    return found;
  }

  function bankButtons(root, preferred) {
    var found = [];
    queryAllDeep(root, "button, a, label, span, li, div, [role='button'], [role='option'], [role='radio']").forEach(function (el) {
      if (!controlVisible(el) || !isClickable(el) || !nearNetBanking(root, el)) return;
      var text = labelsOf(el).map(leadingBank).filter(Boolean)[0];
      if (!text) return;
      found.push({ el: el, text: text });
    });
    found.sort(function (a, b) {
      if (a.el === b.el) return 0;
      var pos = a.el.compareDocumentPosition(b.el);
      if (pos & 4) return -1;
      if (pos & 2) return 1;
      return 0;
    });
    if (preferred) {
      var preferredHits = found.filter(function (item) {
        return labelsOf(item.el).some(function (text) { return matchesPreferred(text, preferred); });
      });
      if (preferredHits.length) return preferredHits;
    }
    return found;
  }

  function pickBank(root, preferred) {
    var selects = bankSelects(root).filter(function (sel) { return nearNetBanking(root, sel); });
    var choice = null;
    selects.some(function (sel) {
      var options = Array.prototype.filter.call(sel.options || [], function (opt) {
        return opt.value && !opt.disabled && isBankText(opt.textContent || "");
      });
      if (!options.length) return false;
      var preferredOpt = preferred && options.filter(function (opt) {
        return matchesPreferred(opt.textContent || "", preferred);
      })[0];
      var opt = preferredOpt || options[0];
      choice = result("select", {
        target: sel,
        kind: "bank",
        code: "BANK",
        phase: "bank_selected",
        detail: preferred && !preferredOpt
          ? "Preferred bank was not listed. Selected " + norm(opt.textContent) + "."
          : "Selected " + norm(opt.textContent) + ".",
        label: norm(opt.textContent),
        value: opt.value,
        attemptKey: "bank"
      });
      return true;
    });
    if (choice) return choice;
    var buttons = bankButtons(root, preferred);
    if (!buttons.length) return null;
    var button = buttons[0];
    var name = labelsOf(button.el).filter(isBankText)[0] || button.text;
    var preferredMissing = preferred && !labelsOf(button.el).some(function (text) {
      return matchesPreferred(text, preferred);
    });
    return click(
      button.el,
      "bank",
      "BANK",
      "bank_selected",
      preferredMissing ? "Preferred bank was not listed. Selected " + name + "." : "Selected " + name + ".",
      "bank",
      false
    );
  }

  function bankReady(root, ctx) {
    if (otherPaymentSelected(root)) return "";
    var selected = selectedBankName(root);
    if (selected) return selected;
    if (ctx && ctx.chosenBank && netBankingSelected(root)) {
      var stillThere = bankButtons(root, "").some(function (item) {
        return labelsOf(item.el).some(function (text) { return matchesPreferred(text, ctx.chosenBank) || norm(text) === norm(ctx.chosenBank); });
      }) || bankSelects(root).some(function (sel) {
        return Array.prototype.some.call(sel.options || [], function (opt) {
          return matchesPreferred(opt.textContent || "", ctx.chosenBank) || norm(opt.textContent) === norm(ctx.chosenBank);
        });
      });
      if (stillThere) return ctx.chosenBank;
    }
    return "";
  }

  function netBankingReady(root, attempts) {
    if (netBankingSelected(root)) return true;
    if (attempts.netBanking > 0 && (bankSelects(root).length || bankButtons(root, "").length || firstMatch(root, OTHER_BANKS_RE))) {
      return true;
    }
    return false;
  }

  function paymentMethodsPresent(root) {
    var blob = byLabel(root, /.*/).map(function (item) { return item.text; }).join(" | ");
    return /net\s*banking|internet\s*banking|upi|cash on delivery|credit|debit|amazon pay|emi|नेट\s*बैंकिंग/i.test(blob);
  }

  function documentMentionsNetBanking(root) {
    var node = root && root.nodeType === 9 ? root.body : root;
    var text = norm((node && (node.innerText || node.textContent) || "").slice(0, 12000));
    return /net\s*banking|internet\s*banking|नेट\s*बैंकिंग|इंटरनेट\s*बैंकिंग/i.test(text);
  }

  function headings(root) {
    return queryAllDeep(root, "h1, h2, h3, h4, .a-text-bold, .a-size-medium")
      .filter(controlVisible)
      .map(function (el) { return norm(el.innerText || el.textContent || ""); })
      .filter(function (text) { return text && text.length < 90; });
  }

  function checkoutContext(root) {
    if (isCaptcha(root) || isSignIn(root)) return true;
    if (netBankingControl(root) || firstMatch(root, ADDRESS_RE) || firstMatch(root, PAYMENT_CONTINUE_RE)) return true;
    if (findPlaceOrder(root)) return true;
    var title = headings(root).join(" | ");
    return /delivery address|payment method|delivery option|shipping speed|select a payment|भुगतान/i.test(title);
  }

  function findPlaceOrder(root) {
    var byId = queryAllDeep(root, "#submitOrderButtonId, #turbo-checkout-pyo-button, input[name='placeYourOrder1'], [name='placeYourOrder1']")
      .filter(function (el) {
        return controlVisible(el) && !el.disabled && el.getAttribute("aria-disabled") !== "true" && !(el.closest && el.closest(".a-button-disabled"));
      });
    if (byId.length) return byId[0];
    var labeled = byLabel(root, PLACE_RE).concat(byLabel(root, PAY_AMOUNT_RE));
    var match = labeled.filter(function (item) {
      if (PRIME_ACCEPT_RE.test(item.text)) return false;
      if (OTHER_PAYMENT_RE.test(item.text) && !NET_RE.test(item.text)) return false;
      return !item.el.disabled && item.el.getAttribute("aria-disabled") !== "true";
    })[0];
    return match ? match.el : null;
  }

  var BUY_NOW_TEXT = /^(buy now|अभी खरीदें)$/i;
  var BUY_NOW_SCOPE = "#buybox, #desktop_buybox, #buyNow, #buyNow_feature_div, #desktop_qualifiedBuyBox, #qualifiedBuybox, form[action*='buynow'], form[action*='buy-now']";

  function disabledWrap(el) {
    if (!el) return true;
    var wrap = el.closest && el.closest(".a-button, button");
    if (wrap && (wrap.classList.contains("a-button-disabled") || wrap.getAttribute("aria-disabled") === "true")) return true;
    if (el.disabled || el.getAttribute("aria-disabled") === "true") return true;
    var inputs = el.querySelectorAll ? el.querySelectorAll("#buy-now-button, input[name='submit.buy-now']") : [];
    if (inputs.length && !Array.prototype.some.call(inputs, function (input) {
      return !input.disabled && !(input.closest && input.closest(".a-button-disabled"));
    })) return true;
    var own = null;
    if (el.matches && el.matches("#buy-now-button, input[name='submit.buy-now'], button")) own = el;
    else if (wrap) own = wrap.querySelector("#buy-now-button, input[name='submit.buy-now'], input.a-button-input, button");
    return !!(own && (own.disabled || (own.closest && own.closest(".a-button-disabled"))));
  }

  function isBuyNowNode(el) {
    if (!el || el.nodeType !== 1 || inIgnoredRegion(el)) return false;
    var id = el.id || "";
    var name = (el.getAttribute && el.getAttribute("name")) || "";
    if (id === "buy-now-button" || name === "submit.buy-now" || id === "submit.buy-now-announce") {
      return !disabledWrap(el);
    }
    if (!labelsOf(el).some(function (text) { return BUY_NOW_TEXT.test(text); })) return false;
    if (disabledWrap(el)) return false;
    if (!(el.closest && el.closest(BUY_NOW_SCOPE))) return false;
    return controlVisible(el);
  }

  function findBuyNowTarget(node) {
    beginScan();
    var el = node && node.nodeType === 1 ? node : node && node.parentElement;
    if (!el || el.nodeType !== 1) return null;
    var cursor = el;
    while (cursor && cursor.nodeType === 1) {
      if (inIgnoredRegion(cursor)) return null;
      if (isBuyNowNode(cursor)) return cursor;
      var root = cursor.getRootNode && cursor.getRootNode();
      if (root && root.host) {
        cursor = root.host;
        continue;
      }
      cursor = cursor.parentElement;
    }
    return null;
  }

  function findBuyNowButton(root) {
    beginScan();
    var nodes = queryAllDeep(root, "#buy-now-button, input[name='submit.buy-now'], #submit\\.buy-now-announce, button, a, span, input[type='submit']");
    var found = null;
    nodes.some(function (el) {
      if (!isBuyNowNode(el)) return false;
      found = el;
      return el.id === "buy-now-button" || (el.getAttribute && el.getAttribute("name") === "submit.buy-now");
    });
    return found || nodes.filter(isBuyNowNode)[0] || null;
  }

  function findReviseControls(root) {
    beginScan();
    return byLabel(root, REVISE_ANY_RE).map(function (item) { return item.el; });
  }

  function decideOrders(root, ctx, attempts) {
    if (!ctx.reviseOpened && attempts.revise < 1) {
      var revise = firstMatch(root, REVISE_CLICK_RE);
      if (revise) {
        return click(
          revise,
          "revise",
          "REVISE",
          "orders",
          "Opened payment options. Pay with the method you want. Amazon ships this order only after that payment succeeds.",
          "revise",
          false
        );
      }
    }
    return wait(
      "orders",
      "Bank sign-in was skipped. Use Change payment method or Revise payment on the new order, then pay with the option you want."
    );
  }

  function decide(root, ctx) {
    beginScan();
    ctx = ctx || {};
    var attempts = attemptsOf(ctx);
    var mode = ctx.mode || (onOrdersPage(root) ? "orders" : "checkout");

    if (mode === "orders" || (ctx.phase === "orders" && onOrdersPage(root))) {
      return decideOrders(root, ctx, attempts);
    }
    if (ctx.submitted) {
      return wait("submitted", "Order submitted. Skipping bank sign-in and opening Your Orders.");
    }
    if (isCaptcha(root)) {
      return stop("CAPTCHA", "Amazon showed a CAPTCHA. Finish it yourself. AmaFast does not solve CAPTCHAs.");
    }
    if (isSignIn(root)) {
      return stop("SIGNIN", "Sign in to Amazon, then click Buy Now again. AmaFast does not type your password.");
    }

    var netControl = netBankingControl(root);
    var decline = firstMatch(root, PRIME_DECLINE_RE);
    var accept = firstMatch(root, PRIME_ACCEPT_RE);
    var productPage = !!(docOf(root).querySelector && docOf(root).querySelector("#productTitle, #buybox, #dp-container, #ppd"));
    if (decline && accept && !netControl && attempts.prime < 2) {
      return click(decline, "prime", "PRIME", "prime", "Declining the Prime offer.", "prime", false);
    }
    if (!productPage && accept && !decline && !netControl && !findPlaceOrder(root) && /prime/i.test(headings(root).join(" ")) && !documentMentionsNetBanking(root) && !paymentMethodsPresent(root)) {
      return stop("PRIME", "Amazon is asking you to join Prime. Decline that offer, then click Buy Now again.");
    }
    if (!checkoutContext(root)) return idle();

    var place = findPlaceOrder(root);
    var paymentContinue = firstMatch(root, PAYMENT_CONTINUE_RE);
    var more = firstMatch(root, MORE_PAY_RE);
    var otherBanks = firstMatch(root, OTHER_BANKS_RE);
    var onPayment = !!(netControl || paymentContinue || bankSelects(root).length || more || /payment method|select a payment|भुगतान विधि/i.test(headings(root).join(" | ")));

    if (onPayment) {
      if (!netBankingReady(root, attempts)) {
        if (netControl && attempts.netBanking < 4) {
          return click(netControl, "netbanking", "NET_BANKING", "payment", "Choosing Internet Banking.", "netBanking", false);
        }
        if (more && attempts.morePayments < 2) {
          return click(more, "more", "MORE_PAY", "payment", "Opening the rest of the payment methods.", "morePayments", false);
        }
        if (documentMentionsNetBanking(root)) {
          return wait("payment", "Internet Banking is on this page. Trying to open it.");
        }
        if (paymentMethodsPresent(root) || attempts.netBanking > 0 || attempts.morePayments > 0) {
          return stop("UNAVAILABLE", "Internet Banking is not offered for this order. Finish checkout yourself.");
        }
        return wait("payment", "Looking for Internet Banking.");
      }

      var readyBank = bankReady(root, ctx);
      if (!readyBank) {
        var picked = pickBank(root, ctx.preferredBank || "");
        if (picked && attempts.bank < 3) return picked;
        if (otherBanks && attempts.otherBanks < 2) {
          return click(otherBanks, "otherBanks", "OTHER_BANKS", "payment", "Opening the bank list.", "otherBanks", false);
        }
        if (attempts.bank > 0 || attempts.otherBanks > 0) {
          return stop("NO_BANK", "Could not choose a bank. Pick Internet Banking yourself and leave the bank page without signing in.");
        }
        return wait("payment", "Looking for a bank list.");
      }

      if (ctx.testMode) {
        return stop("TEST_STOP", "Test mode: Internet Banking and " + readyBank + " are selected. The order was not placed.");
      }
      var continueBtn = paymentContinue || firstMatch(root, CONTINUE_RE);
      if (continueBtn && attempts.paymentContinue < 1) {
        return click(continueBtn, "paymentContinue", "PAYMENT_CONTINUE", "payment", "Continuing with Internet Banking.", "paymentContinue", false);
      }
      if (place && attempts.place < 2) {
        return click(
          place,
          "place",
          "PLACE",
          "submitted",
          "Placing the order with " + readyBank + ". You may see the bank page for a moment. Do not sign in.",
          "place",
          true
        );
      }
      if (place) {
        return stop("PLACE_FAILED", "Amazon did not accept the place-order click. Finish this step yourself.");
      }
      return wait("review", "Internet Banking is selected. Waiting for Amazon's place-order step.");
    }

    var address = firstMatch(root, ADDRESS_RE);
    if (address && attempts.address < 2) {
      return click(address, "address", "ADDRESS", "address", "Using the delivery address already selected on Amazon.", "address", false);
    }

    var deliveryHeading = /delivery option|shipping speed|choose your delivery/i.test(headings(root).join(" | "));
    var continueBtn = firstMatch(root, CONTINUE_RE);
    if (continueBtn && deliveryHeading && attempts.delivery < 2) {
      return click(continueBtn, "delivery", "DELIVERY", "delivery", "Keeping Amazon's selected delivery speed.", "delivery", false);
    }
    if (continueBtn && attempts.address < 2 && /address/i.test(headings(root).join(" | "))) {
      return click(continueBtn, "address", "ADDRESS", "address", "Continuing with the selected address.", "address", false);
    }

    if (place && bankReady(root, ctx) && netBankingReady(root, attempts)) {
      if (ctx.testMode) {
        return stop("TEST_STOP", "Test mode: Internet Banking is selected. The order was not placed.");
      }
      if (attempts.place >= 2) {
        return stop("PLACE_FAILED", "Amazon did not accept the place-order click. Finish this step yourself.");
      }
      return click(place, "place", "PLACE", "submitted", "Placing the order with Internet Banking. Do not sign in on the bank page.", "place", true);
    }

    return wait("checkout", "Waiting for the next checkout step.");
  }

  function isNetBankName(name) {
    var text = norm(name);
    if (!text || text.length > 60) return false;
    if (!/net\s*banking|internet\s*banking|netbanking|नेट\s*बैंकिंग|इंटरनेट\s*बैंकिंग/i.test(text)) return false;
    if (/upi|credit|debit|emi|wallet|cash on delivery|amazon pay/i.test(text)) return false;
    return true;
  }

  function isBankDropdownName(name) {
    var text = norm(name);
    if (!text || text.length > 60 || isNetBankName(text) || isBankText(text)) return false;
    if (/^(choose an option|choose option|select an option|select a bank|select bank|select your bank|select your bank name|bank name|other banks?|all banks?|popular banks?|see all banks?|view all banks?|more banks?|show all banks?|एक विकल्प चुनें|बैंक चुनें|बैंक का चयन करें)$/i.test(text)) return true;
    return /choose an option|select (?:a |your )?bank|other banks|all banks|popular banks/i.test(text);
  }

  function isPayButtonName(name) {
    var text = norm(name);
    if (!text || text.length > 40) return false;
    if (/^continue shopping$/i.test(text)) return false;
    return /^(use this payment method|continue|place your order(?: and pay)?|pay now|proceed to pay|proceed to bank)$/i.test(text) || /^pay\s+(₹|rs\.?|inr)\b/i.test(text);
  }

  function hasPaymentSurface(nodes) {
    return (nodes || []).some(function (node) {
      var name = node && node.name;
      if (!name) return false;
      return isNetBankName(name) || isBankText(name) || /payment method|upi|cash on delivery|credit|debit card/i.test(name);
    });
  }

  function roleRank(role) {
    var value = String(role || "").toLowerCase();
    if (value === "radio" || value === "button" || value === "checkbox" || value === "switch" || value === "combobox" || value === "listbox") return 0;
    if (value === "listitem" || value === "option" || value === "menuitem" || value === "tab") return 1;
    if (value === "link") return 2;
    return 3;
  }

  function pickPaymentAction(nodes, ctx) {
    ctx = ctx || {};
    var attempts = ctx.attempts || {};
    var list = (nodes || []).filter(function (node) {
      return node && node.name && node.backendNodeId && !node.disabled;
    });
    function best(filter) {
      return list.filter(filter).sort(function (a, b) {
        return roleRank(a.role) - roleRank(b.role);
      })[0] || null;
    }
    function chosen(kind, node, detail, finalClick) {
      var attemptKey = kind === "netbanking" ? "netBanking" : (kind === "more" ? "morePayments" : (kind === "paymentContinue" ? "paymentContinue" : kind));
      return {
        kind: kind,
        code: kind === "netbanking" ? "NET_BANKING" : (kind === "paymentContinue" ? "PAYMENT_CONTINUE" : kind.toUpperCase()),
        backendNodeId: node.backendNodeId,
        label: node.name,
        detail: detail,
        final: !!finalClick,
        attemptKey: attemptKey === "place" ? "place" : attemptKey
      };
    }
    var netNodes = list.filter(function (node) { return isNetBankName(node.name); });
    var netChecked = netNodes.some(function (node) { return node.checked; });
    var bankNodes = list.filter(function (node) { return isBankText(node.name) && !isNetBankName(node.name); });
    var checkedBank = bankNodes.filter(function (node) { return node.checked; })[0];

    if (!netChecked && netNodes.length && (attempts.netBanking || 0) < 3) {
      var net = best(function (node) { return isNetBankName(node.name); });
      if (net) return chosen("netbanking", net, "Choosing Internet Banking.", false);
    }
    var netOn = netChecked || (attempts.netBanking || 0) > 0;
    if (netOn && !checkedBank && (attempts.otherBanks || 0) < 1) {
      var dropdown = best(function (node) { return isBankDropdownName(node.name); });
      if (dropdown) return chosen("otherBanks", dropdown, "Opening the bank list.", false);
    } else if (netOn && !checkedBank && !bankNodes.length && (attempts.otherBanks || 0) < 2) {
      var dropdownAgain = best(function (node) { return isBankDropdownName(node.name); });
      if (dropdownAgain) return chosen("otherBanks", dropdownAgain, "Opening the bank list.", false);
    }
    if (!netNodes.length && (attempts.morePayments || 0) < 2) {
      var more = best(function (node) {
        return /^(more ways to pay|other payment options|see all payment methods|another payment method|more payment options)$/i.test(norm(node.name));
      });
      if (more) return chosen("more", more, "Opening the rest of the payment methods.", false);
    }
    if (!checkedBank && bankNodes.length && (netChecked || attempts.netBanking > 0) && (attempts.bank || 0) < 3) {
      var preferredNode = ctx.preferredBank ? best(function (node) {
        return isBankText(node.name) && matchesPreferred(node.name, ctx.preferredBank);
      }) : null;
      var bank = preferredNode || best(function (node) { return isBankText(node.name) && !isNetBankName(node.name); });
      if (bank) {
        var missing = ctx.preferredBank && !matchesPreferred(bank.name, ctx.preferredBank);
        return chosen("bank", bank, missing ? "Preferred bank was not listed. Selected " + bank.name + "." : "Selected " + bank.name + ".", false);
      }
    }
    var bankReady = !!checkedBank || ((attempts.bank || 0) > 0 && (netChecked || attempts.netBanking > 0));
    if (bankReady && ctx.testMode) {
      return { kind: "stop", code: "TEST_STOP", detail: "Test mode: Internet Banking is selected. The order was not placed.", final: false };
    }
    if (bankReady && (attempts.place || 0) < 2 && (attempts.paymentContinue || 0) < 2) {
      var pay = best(function (node) { return isPayButtonName(node.name) && roleRank(node.role) < 3; });
      if (pay) {
        var finalClick = /place your order|pay now|^pay\s/i.test(norm(pay.name));
        if (!finalClick && (attempts.paymentContinue || 0) >= 1) {
          pay = best(function (node) { return /place your order|pay now|^pay\s/i.test(norm(node.name)) && roleRank(node.role) < 3; });
          finalClick = !!pay;
        }
        if (pay) {
          return chosen(finalClick ? "place" : "paymentContinue", pay, finalClick ? "Placing the order. Do not sign in at the bank." : "Continuing with Internet Banking.", finalClick);
        }
      }
    }
    if (!netNodes.length && !bankNodes.length && list.some(function (node) { return /upi|credit|debit|cash on delivery/i.test(node.name); })) {
      return { kind: "stop", code: "UNAVAILABLE", detail: "Internet Banking is not offered for this order. Finish checkout yourself.", final: false };
    }
    return null;
  }

  function activate(el, kind) {
    if (!el) return false;
    var target = el;
    if (kind === "netbanking" || kind === "bank" || kind === "otherBanks" || kind === "more") {
      var row = el.closest && el.closest("label, [role='radio'], [role='button'], [role='option'], .a-button, .pmts-instrument-box, .pmts-selectable-tile, li, [tabindex]");
      target = row || el;
    } else {
      var input = el.closest && el.closest(".a-button") && el.closest(".a-button").querySelector("input[type='submit'], input[type='button'], input.a-button-input, button");
      target = input || ((el.matches && el.matches("button, a, input, [role='button']")) ? el : (el.closest && el.closest("button, a, [role='button']"))) || el;
    }
    if (target.disabled) return false;
    target.click();
    return true;
  }

  function applySelect(el, value) {
    if (!el) return false;
    Array.prototype.forEach.call(el.options || [], function (opt) {
      opt.selected = opt.value === value;
    });
    el.value = value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  globalThis.AmaFastEngine = {
    decide: decide,
    activate: activate,
    applySelect: applySelect,
    findBuyNowTarget: findBuyNowTarget,
    findBuyNowButton: findBuyNowButton,
    findReviseControls: findReviseControls,
    isAmazonUrl: isAmazonUrl,
    shouldBringBack: shouldBringBack,
    isBankText: isBankText,
    isPayButtonName: isPayButtonName,
    pickPaymentAction: pickPaymentAction,
    hasPaymentSurface: hasPaymentSurface
  };
})();
