(function () {
  "use strict";

  var DEFAULTS = {
    enabled: true,
    testMode: false,
    preferredBank: "",
    returnToOrders: true,
    showDeals: true
  };

  var enabled = document.getElementById("enabled");
  var testMode = document.getElementById("testMode");
  var returnToOrders = document.getElementById("returnToOrders");
  var showDeals = document.getElementById("showDeals");
  var preferredBank = document.getElementById("preferredBank");
  var saved = document.getElementById("saved");

  function fill(settings) {
    enabled.checked = settings.enabled !== false;
    testMode.checked = !!settings.testMode;
    returnToOrders.checked = settings.returnToOrders !== false;
    showDeals.checked = settings.showDeals !== false;
    preferredBank.value = settings.preferredBank || "";
  }

  function collect() {
    return {
      enabled: enabled.checked,
      testMode: testMode.checked,
      returnToOrders: returnToOrders.checked,
      showDeals: showDeals.checked,
      preferredBank: preferredBank.value.trim()
    };
  }

  chrome.storage.local.get("settings").then(function (stored) {
    fill(Object.assign({}, DEFAULTS, stored.settings || {}));
  });

  document.getElementById("form").addEventListener("submit", function (event) {
    event.preventDefault();
    var settings = collect();
    chrome.storage.local.set({ settings: settings }).then(function () {
      saved.textContent = "Saved on this browser.";
    });
  });

  document.getElementById("clear").addEventListener("click", function () {
    chrome.storage.local.set({ settings: DEFAULTS }).then(function () {
      fill(DEFAULTS);
      saved.textContent = "Settings cleared. An in-progress checkout is left as it is until you click Stop.";
    });
  });
})();
