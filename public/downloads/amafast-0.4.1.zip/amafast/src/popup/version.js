"use strict";

/* Version comparison for the popup's update banner. Mirrors isNewer() in
   src/deals.js, which the service worker uses; kept separate because a popup
   cannot importScripts the worker's module. Covered by test/run.js. */
var AmaFastDealsVersion = {
  isNewer: function (latest, installed) {
    var a = String(latest || "").split(".").map(Number);
    var b = String(installed || "").split(".").map(Number);
    for (var i = 0; i < Math.max(a.length, b.length); i += 1) {
      var x = a[i] || 0;
      var y = b[i] || 0;
      if (x !== y) return x > y;
    }
    return false;
  }
};
