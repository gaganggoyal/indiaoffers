"use strict";

importScripts("engine.js", "deals.js");

var DEFAULT_SETTINGS = {
  enabled: true,
  testMode: false,
  preferredBank: "",
  returnToOrders: true,
  showDeals: true
};

var DEALS_ALARM = "zap-deals";
var DEALS_PERIOD_MIN = 20;

var ORDERS_URL = "https://www.amazon.in/gp/your-account/order-history?ref_=zap";
var RETURN_WAIT_MS = 3500;
var PLACE_CONFIRM_MS = 5000;

function emptyAttempts() {
  return {
    address: 0,
    delivery: 0,
    morePayments: 0,
    netBanking: 0,
    otherBanks: 0,
    bank: 0,
    paymentContinue: 0,
    place: 0,
    prime: 0,
    revise: 0
  };
}

function delay(ms) {
  var end = Date.now() + ms;
  return new Promise(function (resolve) {
    function tick() {
      if (Date.now() >= end) {
        resolve();
        return;
      }
      chrome.runtime.getPlatformInfo(function () {
        setTimeout(tick, 250);
      });
    }
    tick();
  });
}

async function getSettings() {
  var data = await chrome.storage.local.get("settings");
  return Object.assign({}, DEFAULT_SETTINGS, data.settings || {});
}

async function getRun() {
  var data = await chrome.storage.session.get("run");
  return data.run || null;
}

async function setRun(run) {
  await chrome.storage.session.set({ run: run });
  return run;
}

async function patch(partial) {
  var current = await getRun();
  if (!current) return null;
  var next = Object.assign({}, current, partial);
  next.attempts = Object.assign(emptyAttempts(), current.attempts || {}, partial.attempts || {});
  if (partial.code && partial.code !== "WAIT" && partial.code !== "IDLE") {
    var log = (current.log || []).concat([{ t: Date.now(), code: partial.code }]);
    next.log = log.slice(-40);
  }
  if (!partial.product) next.product = current.product || partial.product;
  return setRun(next);
}

function freshRun(tabId, product) {
  return {
    active: true,
    tabId: tabId,
    phase: "armed",
    code: "ARM",
    detail: product && product.title
      ? "Buy Now clicked for “" + product.title + "”. Choosing Internet Banking."
      : "Buy Now clicked. Choosing Internet Banking and a bank.",
    product: {
      asin: (product && product.asin) || "",
      title: (product && product.title) || "",
      price: (product && product.price) || ""
    },
    chosenBank: "",
    startedAt: Date.now(),
    expiresAt: Date.now() + 3 * 60 * 1000,
    submitted: false,
    returnScheduled: false,
    reviseOpened: false,
    attempts: emptyAttempts(),
    log: [{ t: Date.now(), code: "ARM" }]
  };
}

async function arm(tabId, product) {
  var settings = await getSettings();
  if (!settings.enabled || !tabId) return { armed: false, settings: settings };
  var current = await getRun();
  var placed = !!(current && (current.submitted || (current.attempts && current.attempts.place > 0)));
  if (current && current.tabId === tabId && placed && Date.now() < current.expiresAt) {
    /* A second Buy Now must not hand back a run with submitted cleared and the
       attempt counters zeroed — that is how you end up with two orders. */
    return { armed: true, run: current, settings: settings, already: true };
  }
  if (current && current.tabId === tabId && current.active && Date.now() < current.expiresAt && Date.now() - current.startedAt < 8000) {
    return { armed: true, run: current, settings: settings, already: true };
  }
  var run = freshRun(tabId, product);
  await setRun(run);
  watchPayment(tabId);
  return { armed: true, run: run, settings: settings };
}

async function scheduleReturn(tabId, source) {
  var current = await getRun();
  if (!current || current.tabId !== tabId || !ZapEngine.shouldBringBack(current)) return;
  if (source === "iframe") {
    current = await patch({ bankFrameLeft: true });
  }
  if (!current || current.returnScheduled) return;
  var settings = await getSettings();
  if (!settings.returnToOrders) {
    await patch({
      returnScheduled: true,
      phase: "at_bank",
      code: "AT_BANK",
      detail: "The bank page is open. Zap does not sign in. Close it, then use Revise payment on Your Orders."
    });
    return;
  }
  await patch({
    returnScheduled: true,
    phase: "leaving_bank",
    code: "RETURN",
    detail: "Skipping bank sign-in. Opening Your Orders so you can pay with your own method."
  });
  await delay(RETURN_WAIT_MS);
  var latest = await getRun();
  if (!latest || latest.tabId !== tabId || !ZapEngine.shouldBringBack(latest)) return;
  var tab = null;
  try {
    tab = await chrome.tabs.get(tabId);
  } catch (err) {
    return;
  }
  var stillOnAmazon = !!(tab.url && ZapEngine.isAmazonUrl(tab.url));
  if (stillOnAmazon && !latest.bankFrameLeft) {
    await patch({
      returnScheduled: false,
      phase: latest.submitted ? "submitted" : "payment"
    });
    return;
  }
  await patch({
    active: true,
    phase: "orders",
    code: "ORDERS",
    detail: "Bank sign-in was skipped. Use Change payment method on the new order and pay with the option you want. Amazon ships the order only after that payment succeeds.",
    expiresAt: Date.now() + 2 * 60 * 1000
  });
  try {
    await chrome.tabs.update(tabId, { url: ORDERS_URL });
  } catch (err) {
    await patch({
      phase: "stopped",
      active: false,
      code: "RETURN_FAILED",
      detail: "Could not open Your Orders automatically. Open Your Orders and use Revise payment."
    });
  }
}

var driving = {};

function cdp(tabId, method, params) {
  return new Promise(function (resolve, reject) {
    chrome.debugger.sendCommand({ tabId: tabId }, method, params || {}, function (result) {
      var err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message));
      else resolve(result || {});
    });
  });
}

function attachDebugger(tabId) {
  return new Promise(function (resolve, reject) {
    chrome.debugger.attach({ tabId: tabId }, "1.3", function () {
      var err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message));
      else resolve();
    });
  });
}

function detachDebugger(tabId) {
  return new Promise(function (resolve) {
    chrome.debugger.detach({ tabId: tabId }, function () {
      resolve();
    });
  });
}

function axValue(value) {
  if (!value) return "";
  if (typeof value === "string") return value;
  if (typeof value.value === "string" || typeof value.value === "boolean") return value.value;
  return "";
}

function simplifyAx(nodes) {
  var seen = {};
  var out = [];
  (nodes || []).forEach(function (node) {
    if (!node || node.ignored || !node.backendDOMNodeId || seen[node.backendDOMNodeId]) return;
    var name = axValue(node.name);
    if (!name) return;
    seen[node.backendDOMNodeId] = true;
    var checked = false;
    var disabled = false;
    (node.properties || []).forEach(function (prop) {
      var flag = axValue(prop.value);
      if ((prop.name === "checked" || prop.name === "selected" || prop.name === "pressed") && (flag === true || flag === "true")) checked = true;
      if (prop.name === "disabled" && (flag === true || flag === "true")) disabled = true;
    });
    out.push({
      name: String(name),
      role: String(axValue(node.role) || ""),
      backendNodeId: node.backendDOMNodeId,
      checked: checked,
      disabled: disabled
    });
  });
  return out;
}

async function collectAx(tabId) {
  var all = [];
  await cdp(tabId, "Accessibility.enable");
  await cdp(tabId, "DOM.enable");
  try {
    var main = await cdp(tabId, "Accessibility.getFullAXTree", {});
    all = all.concat(main.nodes || []);
  } catch (err) {
    /* The per-frame read below still covers the payment widget. */
  }
  try {
    var tree = await cdp(tabId, "Page.getFrameTree", {});
    var frames = [];
    (function walk(frameTree) {
      if (!frameTree) return;
      if (frameTree.frame && frameTree.frame.id) frames.push(frameTree.frame.id);
      (frameTree.childFrames || []).forEach(walk);
    })(tree.frameTree);
    for (var i = 0; i < frames.length; i += 1) {
      try {
        var sub = await cdp(tabId, "Accessibility.getFullAXTree", { frameId: frames[i] });
        all = all.concat(sub.nodes || []);
      } catch (err) {
        /* Some frames do not expose an accessibility tree. */
      }
    }
  } catch (err) {
    /* The main tree is enough when frames are not listed. */
  }
  return simplifyAx(all);
}

function axSignature(nodes) {
  return (nodes || []).map(function (node) {
    return node.backendNodeId + ":" + (node.checked ? 1 : 0) + ":" + node.name;
  }).join("|");
}

/* Wait on the page instead of on the clock. Same ceiling as the flat delay it
   replaces, but the usual case returns in a fraction of it. */
async function settle(tabId, before, capMs) {
  var deadline = Date.now() + capMs;
  var step = 80;
  while (Date.now() < deadline) {
    await delay(Math.min(step, Math.max(0, deadline - Date.now())));
    var nodes;
    try {
      nodes = await collectAx(tabId);
    } catch (err) {
      return;
    }
    if (axSignature(nodes) !== before) return;
    step = Math.min(step * 2, 300);
  }
}

/* Report "not placed" only on positive evidence: still on the payment URL with
   a live pay button. An unreadable or vanished page counts as placed, so a
   failure to read can never cause a second order. */
async function confirmPlaced(tabId, capMs) {
  var deadline = Date.now() + capMs;
  var step = 120;
  while (Date.now() < deadline) {
    await delay(Math.min(step, Math.max(0, deadline - Date.now())));
    var tab;
    try {
      tab = await chrome.tabs.get(tabId);
    } catch (err) {
      return true;
    }
    if (!tab.url || !ZapEngine.isAmazonUrl(tab.url)) return true;
    if (!isPaymentUrl(tab.url)) return true;
    var nodes;
    try {
      nodes = await collectAx(tabId);
    } catch (err) {
      return true;
    }
    var stillPayable = nodes.some(function (node) {
      return node.name && !node.disabled && ZapEngine.isPayButtonName(node.name);
    });
    if (!stillPayable) return true;
    step = Math.min(step * 2, 400);
  }
  return false;
}

async function clickNode(tabId, backendNodeId) {
  try {
    await cdp(tabId, "DOM.scrollIntoViewIfNeeded", { backendNodeId: backendNodeId });
  } catch (err) {
    /* The node may already be on screen. */
  }
  var quads = await cdp(tabId, "DOM.getContentQuads", { backendNodeId: backendNodeId });
  var quad = quads.quads && quads.quads[0];
  if (!quad || quad.length < 8) throw new Error("Payment option has no clickable area.");
  var x = (quad[0] + quad[2] + quad[4] + quad[6]) / 4;
  var y = (quad[1] + quad[3] + quad[5] + quad[7]) / 4;
  await cdp(tabId, "Input.dispatchMouseEvent", { type: "mouseMoved", x: x, y: y });
  await cdp(tabId, "Input.dispatchMouseEvent", { type: "mousePressed", x: x, y: y, button: "left", clickCount: 1 });
  await cdp(tabId, "Input.dispatchMouseEvent", { type: "mouseReleased", x: x, y: y, button: "left", clickCount: 1 });
}

function bankSelectExpression(preferred) {
  var safe = String(preferred || "").replace(/[^\w\s.&-]/g, "").slice(0, 40);
  return "(function(){\n" +
    "var preferred=" + JSON.stringify(safe) + ".toLowerCase();\n" +
    "function walk(node, out){\n" +
    "  if(!node||!node.querySelectorAll) return;\n" +
    "  node.querySelectorAll('select').forEach(function(sel){ out.push(sel); });\n" +
    "  node.querySelectorAll('*').forEach(function(el){ if(el.shadowRoot) walk(el.shadowRoot, out); });\n" +
    "}\n" +
    "var selects=[]; walk(document, selects);\n" +
    "function bankish(text){\n" +
    "  var t=String(text||'').replace(/\\s+/g,' ').trim();\n" +
    "  if(!t||t.length>60) return false;\n" +
    "  if(/select|choose|option|popular|other bank|all bank/i.test(t)) return false;\n" +
    "  return /bank|sbi|hdfc|icici|axis|kotak|baroda|pnb|canara|idbi|yes\\b|indusind|union bank|federal/i.test(t);\n" +
    "}\n" +
    "for(var i=0;i<selects.length;i++){\n" +
    "  var sel=selects[i]; if(sel.disabled) continue;\n" +
    "  var options=Array.prototype.slice.call(sel.options||[]);\n" +
    "  var banks=options.filter(function(opt){ return opt.value && !opt.disabled && bankish(opt.textContent); });\n" +
    "  if(!banks.length) continue;\n" +
    "  var match=preferred && banks.filter(function(opt){ return opt.textContent.toLowerCase().indexOf(preferred)!==-1; })[0];\n" +
    "  var opt=match||banks[0];\n" +
    "  sel.value=opt.value;\n" +
    "  Array.prototype.forEach.call(sel.options, function(item){ item.selected=item.value===opt.value; });\n" +
    "  sel.dispatchEvent(new Event('input',{bubbles:true}));\n" +
    "  sel.dispatchEvent(new Event('change',{bubbles:true}));\n" +
    "  return String(opt.textContent||'').replace(/\\s+/g,' ').trim();\n" +
    "}\n" +
    "return '';\n" +
    "})()";
}

async function chooseBankInSelects(tabId, preferred) {
  var tree;
  try {
    tree = await cdp(tabId, "Page.getFrameTree", {});
  } catch (err) {
    return "";
  }
  var frames = [];
  (function walk(frameTree) {
    if (!frameTree) return;
    if (frameTree.frame && frameTree.frame.id) frames.push(frameTree.frame.id);
    (frameTree.childFrames || []).forEach(walk);
  })(tree.frameTree);
  var expression = bankSelectExpression(preferred);
  for (var i = 0; i < frames.length; i += 1) {
    try {
      var world = await cdp(tabId, "Page.createIsolatedWorld", {
        frameId: frames[i],
        worldName: "zap-bank",
        grantUniveralAccess: true
      });
      var result = await cdp(tabId, "Runtime.evaluate", {
        contextId: world.executionContextId,
        expression: expression,
        returnByValue: true
      });
      var value = result.result && result.result.value;
      if (value) return String(value);
    } catch (err) {
      /* This frame may not host the bank dropdown. */
    }
  }
  return "";
}

function isPaymentUrl(url) {
  return ZapEngine.isAmazonUrl(url) && /payselect|\/spc\/|\/pay(?:\?|\/|$)|payment/i.test(url);
}

function watchPayment(tabId) {
  return drivePayment(tabId);
}

async function drivePayment(tabId) {
  if (!tabId || driving[tabId]) return { ok: true, already: true, drove: true };
  driving[tabId] = true;
  var attached = false;
  try {
    var current = await getRun();
    if (!current || !current.active || current.tabId !== tabId || current.submitted || current.phase === "test_stopped" || current.phase === "orders" || current.phase === "at_bank") {
      return { ok: false, reason: "idle" };
    }
    await attachDebugger(tabId);
    attached = true;
    await patch({ detail: "Reading the payment options." });
    var settings = await getSettings();
    while (true) {
      var run = await getRun();
      if (!run || !run.active || run.tabId !== tabId || run.submitted || run.phase === "stopped" || run.phase === "test_stopped" || run.phase === "orders") break;
      if (Date.now() > run.expiresAt) break;
      var tab = await chrome.tabs.get(tabId);
      if (!tab.url || !ZapEngine.isAmazonUrl(tab.url)) break;
      settings = await getSettings();
      var nodes = [];
      try {
        nodes = await collectAx(tabId);
      } catch (err) {
        try {
          await attachDebugger(tabId);
          attached = true;
        } catch (attachErr) {
          if (!/already/i.test(String(attachErr && attachErr.message))) throw err;
        }
        await delay(500);
        continue;
      }
      if (!ZapEngine.hasPaymentSurface(nodes)) {
        await delay(250);
        continue;
      }
      var action = ZapEngine.pickPaymentAction(nodes, {
        preferredBank: settings.preferredBank || "",
        testMode: !!settings.testMode,
        attempts: run.attempts || {}
      });
      if (!action) {
        await patch({
          phase: "payment",
          detail: run.attempts && run.attempts.netBanking > 0
            ? "Internet Banking is selected. Opening the bank list."
            : "Payment page is open. Looking for Internet Banking."
        });
        await delay(250);
        continue;
      }
      if (action.kind === "stop") {
        await patch({
          active: false,
          phase: action.code === "TEST_STOP" ? "test_stopped" : "stopped",
          code: action.code,
          detail: action.detail
        });
        break;
      }
      var attempts = Object.assign({}, run.attempts || {});
      if (action.attemptKey) attempts[action.attemptKey] = (attempts[action.attemptKey] || 0) + 1;
      /* submitted is set only once the page confirms it, never ahead of the
         click — otherwise a click that misses leaves the run wedged in
         "submitted" and sends you to Your Orders looking for an order that was
         never created. shouldBringBack() already keys off attempts.place, so
         the return-to-orders path still works if this frame is torn down
         mid-navigation. */
      await patch({
        attempts: attempts,
        phase: action.final ? "placing" : "payment",
        code: action.code,
        detail: action.detail,
        chosenBank: action.kind === "bank" ? action.label : (run.chosenBank || "")
      });
      var before = axSignature(nodes);
      var clicked = true;
      try {
        await clickNode(tabId, action.backendNodeId);
      } catch (clickErr) {
        if (!/no clickable area/i.test(String(clickErr && clickErr.message))) throw clickErr;
        clicked = false;
      }
      if (action.kind === "otherBanks") {
        var pickedBank = await chooseBankInSelects(tabId, settings.preferredBank || "");
        if (pickedBank) {
          var bankAttempts = Object.assign({}, attempts);
          bankAttempts.bank = (bankAttempts.bank || 0) + 1;
          await patch({
            attempts: bankAttempts,
            chosenBank: pickedBank,
            phase: "bank_selected",
            code: "BANK",
            detail: "Selected " + pickedBank + "."
          });
        }
      }
      if (action.final) {
        var landed = clicked && await confirmPlaced(tabId, PLACE_CONFIRM_MS);
        if (landed) {
          var after = await getRun();
          await patch(after && after.phase === "placing"
            ? {
                submitted: true,
                phase: "submitted",
                code: "PLACE",
                detail: "Order placed. Do not sign in at the bank — Zap will open Your Orders."
              }
            : { submitted: true });
          break;
        }
        if ((attempts.place || 0) >= 2) {
          await patch({
            active: false,
            phase: "stopped",
            code: "PLACE_FAILED",
            detail: "Amazon did not accept the place-order click. Finish this step yourself."
          });
          break;
        }
        await patch({
          phase: "payment",
          detail: "The place-order click did not register. Trying once more."
        });
        continue;
      }
      await settle(tabId, before, 900);
    }
    return { ok: true, drove: true };
  } catch (err) {
    await patch({
      driveFailed: true,
      phase: "payment",
      detail: "Could not click the payment option (" + err.message + "). Reload Zap and allow the debugging prompt, then click Buy Now again."
    });
    return { ok: false, drove: false, error: err.message };
  } finally {
    driving[tabId] = false;
    if (attached) await detachDebugger(tabId);
  }
}

async function refreshDeals(force) {
  var cache = await ZapDeals.refresh(force);
  var stored = await chrome.storage.local.get("dealsSeenAt");
  var count = ZapDeals.unseen(cache, stored.dealsSeenAt || 0);
  try {
    await chrome.action.setBadgeText({ text: count > 0 ? String(Math.min(count, 99)) : "" });
    await chrome.action.setBadgeBackgroundColor({ color: "#0f6e56" });
  } catch (err) {
    /* No action badge on some surfaces; the popup still lists the deals. */
  }
  return cache;
}

chrome.runtime.onInstalled.addListener(function () {
  chrome.storage.local.get("settings").then(function (stored) {
    /* Genuinely first run means no stored settings — not merely an "install"
       reason, which Chrome also reports when an unpacked extension is
       reloaded. Keying on the reason reset a developer's settings on every
       reload, and would have reset a real user's on every version bump. */
    var firstRun = !stored.settings;
    var next = Object.assign({}, DEFAULT_SETTINGS, stored.settings || {});
    if (firstRun) {
      /* Start in Test mode so a new user watches a checkout run to the bank
         step without an order being placed. */
      next.testMode = true;
      chrome.storage.local.set({ dealsSeenAt: Date.now() });
      chrome.runtime.openOptionsPage();
    }
    chrome.storage.local.set({ settings: next });
  });
  chrome.alarms.create(DEALS_ALARM, { periodInMinutes: DEALS_PERIOD_MIN, when: Date.now() + 1000 });
});

chrome.runtime.onStartup.addListener(function () {
  chrome.alarms.create(DEALS_ALARM, { periodInMinutes: DEALS_PERIOD_MIN, when: Date.now() + 1000 });
  refreshDeals(false);
});

chrome.alarms.onAlarm.addListener(function (alarm) {
  if (alarm.name === DEALS_ALARM) refreshDeals(false);
});

chrome.tabs.onUpdated.addListener(function (tabId, info) {
  if (!info.url) return;
  if (!ZapEngine.isAmazonUrl(info.url)) {
    scheduleReturn(tabId, "url");
    return;
  }
  if (!isPaymentUrl(info.url)) return;
  getRun().then(function (run) {
    if (run && run.active && run.tabId === tabId && !run.submitted) drivePayment(tabId);
  });
});

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  var tabId = sender.tab && sender.tab.id;
  var job = Promise.resolve(null);
  if (!message || !message.type) {
    sendResponse({ ok: false });
    return false;
  }
  if (message.type === "getState") {
    job = Promise.all([getSettings(), getRun()]).then(function (pair) {
      return { settings: pair[0], run: pair[1], tabId: tabId || null };
    });
  } else if (message.type === "saveSettings") {
    job = getSettings().then(function (current) {
      var next = Object.assign({}, current, message.settings || {});
      return chrome.storage.local.set({ settings: next }).then(function () {
        return { settings: next };
      });
    });
  } else if (message.type === "arm") {
    job = arm(tabId, message.product || {});
  } else if (message.type === "stop") {
    job = patch({
      active: false,
      phase: "stopped",
      code: "STOP",
      detail: message.reason || "Stopped."
    });
  } else if (message.type === "patch") {
    job = patch(message.patch || {});
  } else if (message.type === "amazonHiding") {
    job = scheduleReturn(tabId, "hide");
  } else if (message.type === "leftCheckout") {
    job = scheduleReturn(tabId, "iframe");
  } else if (message.type === "frameHiding") {
    job = getRun().then(function (current) {
      if (!current || current.tabId !== tabId || !current.submitted) return null;
      return scheduleReturn(tabId, "iframe");
    });
  } else if (message.type === "frameStillAmazon") {
    job = getRun().then(function (current) {
      if (!current || current.tabId !== tabId || current.phase === "orders" || !current.bankFrameLeft) return null;
      return patch({ bankFrameLeft: false });
    });
  } else if (message.type === "drivePayment") {
    job = drivePayment(tabId);
  } else if (message.type === "amazonAlive") {
    job = Promise.resolve({ ok: true });
  } else if (message.type === "getDeals") {
    job = ZapDeals.cached().then(function (cache) {
      if (cache) refreshDeals(false);
      return cache || refreshDeals(false);
    }).then(function (cache) {
      return {
        deals: (cache && cache.deals) || [],
        updated: (cache && cache.updated) || "",
        latest: (cache && cache.latest) || null,
        browse: (cache && cache.browse) || null
      };
    });
  } else if (message.type === "refreshDeals") {
    job = refreshDeals(true).then(function (cache) {
      return {
        deals: (cache && cache.deals) || [],
        updated: (cache && cache.updated) || "",
        latest: (cache && cache.latest) || null,
        browse: (cache && cache.browse) || null
      };
    });
  } else if (message.type === "dealForAsin") {
    job = getSettings().then(function (settings) {
      if (settings.showDeals === false) return { deal: null };
      return ZapDeals.byAsin(message.asin).then(function (deal) {
        return { deal: deal || null };
      });
    });
  } else if (message.type === "dealsSeen") {
    job = chrome.storage.local.set({ dealsSeenAt: Date.now() }).then(function () {
      return chrome.action.setBadgeText({ text: "" }).catch(function () {});
    }).then(function () {
      return { ok: true };
    });
  } else if (message.type === "openDeal") {
    /* Only ever a validated indiaoffers.in /go/ URL — see deals.js. */
    job = Promise.resolve(ZapDeals.outboundUrl(String(message.go || "").replace(ZapDeals.ORIGIN, "")))
      .then(function (url) {
        if (!url) return { ok: false, error: "Not a valid deal link." };
        return chrome.tabs.create({ url: url }).then(function () { return { ok: true }; });
      });
  }
  job.then(function (value) {
    sendResponse(value || { ok: true });
  }).catch(function (err) {
    sendResponse({ ok: false, error: String(err && err.message || err) });
  });
  return true;
});
